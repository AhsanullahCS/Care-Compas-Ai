"""Builds dataset/demo_hospitals.json -- a SYNTHETIC demo dataset for SehatRoute AI.

* Hospital names are fictional (suffix "(Demo)").
* Coordinates are FIXED, hand-entered, approximate area locations (not random, not surveyed).
  They are flagged location_verified=false until an admin verifies them.
* Prices, doctors, scheme acceptance and treatment availability are synthetic (seeded RNG so the
  file is reproducible). Nothing here is verified information.
Run: python dataset/build_demo_dataset.py
"""
import json
import random
from pathlib import Path

rng = random.Random(2026)

CATEGORIES = {
    "Cardiology": "Cardiologist", "Nephrology": "Nephrologist", "Oncology": "Oncologist",
    "Orthopedics": "Orthopedic Surgeon", "Neurology": "Neurologist", "Gastroenterology": "Gastroenterologist",
    "Urology": "Urologist", "Gynecology": "Gynecologist", "Ophthalmology": "Ophthalmologist",
    "General Surgery": "General Surgeon",
}

# name, category, base private price (PKR, synthetic), advanced?
TREATMENTS = [
    ("Angiography", "Cardiology", 45000, False, "Imaging of heart arteries to check for blockages."),
    ("Angioplasty (Stent)", "Cardiology", 450000, False, "Opening a blocked artery and placing a stent."),
    ("CABG (Bypass Surgery)", "Cardiology", 900000, True, "Coronary artery bypass graft surgery."),
    ("Hemodialysis", "Nephrology", 9000, False, "Dialysis session for kidney failure (per session)."),
    ("Kidney Transplant", "Nephrology", 2500000, True, "Kidney transplant surgery and initial care."),
    ("Chemotherapy", "Oncology", 120000, False, "Chemotherapy treatment (per cycle)."),
    ("Radiotherapy", "Oncology", 350000, True, "Radiation therapy course."),
    ("Knee Replacement", "Orthopedics", 600000, False, "Total knee replacement surgery."),
    ("Fracture Fixation", "Orthopedics", 220000, False, "Surgical fixation of bone fractures."),
    ("Spine Surgery", "Orthopedics", 800000, True, "Surgery for spinal conditions."),
    ("Stroke Care", "Neurology", 300000, False, "Acute stroke management and rehabilitation start."),
    ("Epilepsy Management", "Neurology", 60000, False, "Specialist epilepsy assessment and management."),
    ("Endoscopy", "Gastroenterology", 18000, False, "Upper GI endoscopy procedure."),
    ("Liver Disease Management", "Gastroenterology", 150000, True, "Specialist care for chronic liver conditions."),
    ("Lithotripsy", "Urology", 90000, False, "Non-invasive kidney stone fragmentation."),
    ("Prostate Surgery", "Urology", 280000, False, "Surgical treatment of prostate conditions."),
    ("C-Section", "Gynecology", 140000, False, "Caesarean delivery."),
    ("Cataract Surgery", "Ophthalmology", 55000, False, "Lens replacement surgery."),
    ("Appendectomy", "General Surgery", 150000, False, "Surgical removal of the appendix."),
    ("Hernia Repair", "General Surgery", 130000, False, "Surgical hernia repair."),
]

PROGRAMS = [
    ("Sehat Card Plus", "government_card", "Government health insurance card scheme. Coverage and eligibility vary by region; confirm with the official helpline and the hospital."),
    ("Private Health Insurance", "insurance", "Private insurance plans. Panel hospitals and covered treatments differ by insurer and policy."),
    ("Zakat Medical Assistance", "zakat", "Zakat-funded medical support for eligible patients, usually via hospital or district zakat committees."),
    ("Hospital Welfare Fund", "welfare", "Discounts or free treatment through a hospital's own welfare department after assessment."),
    ("Bait-ul-Mal Medical Aid", "aid", "Government financial aid for eligible patients with serious illnesses."),
]

# name, type, city, area, lat, lng, size(L/M/S), departments
H = [
    ("Capital Federal General Hospital", "government", "Islamabad", "G-8", 33.7050, 73.0490, "L", ["Cardiology", "Nephrology", "Gastroenterology", "General Surgery", "Neurology", "Gynecology", "Orthopedics", "Urology"]),
    ("Rawalpindi City Teaching Hospital", "government", "Rawalpindi", "Satellite Town", 33.6340, 73.0640, "L", ["Cardiology", "Orthopedics", "Gynecology", "General Surgery", "Urology", "Ophthalmology", "Nephrology"]),
    ("Cantonment Cardiac Centre", "semi_government", "Rawalpindi", "Saddar", 33.5960, 73.0480, "L", ["Cardiology", "General Surgery"]),
    ("Murree Road District Hospital", "government", "Rawalpindi", "Murree Road", 33.6250, 73.0600, "M", ["General Surgery", "Gynecology", "Orthopedics", "Ophthalmology"]),
    ("Chaklala Civil Hospital", "government", "Rawalpindi", "Chaklala", 33.6050, 73.0800, "M", ["General Surgery", "Gynecology", "Orthopedics"]),
    ("I-10 Federal Hospital", "government", "Islamabad", "I-10", 33.6460, 73.0390, "M", ["General Surgery", "Gynecology", "Urology", "Nephrology"]),
    ("Taxila Teaching Hospital", "government", "Taxila", "Taxila", 33.7460, 72.8250, "M", ["General Surgery", "Gynecology", "Orthopedics", "Neurology"]),
    ("Wah Cantt General Hospital", "semi_government", "Wah Cantt", "Wah Cantt", 33.7700, 72.7500, "M", ["Cardiology", "General Surgery", "Gynecology", "Ophthalmology", "Orthopedics"]),
    ("Westridge Military Medical Centre", "semi_government", "Rawalpindi", "Westridge", 33.5900, 73.0300, "L", ["Cardiology", "Oncology", "Neurology", "Urology", "Orthopedics", "General Surgery", "Gastroenterology"]),
    ("Murree Hill District Hospital", "government", "Murree", "Murree", 33.9070, 73.3900, "S", ["General Surgery", "Gynecology", "Orthopedics"]),
    ("Al-Khidmat Welfare Kidney Centre", "semi_government", "Rawalpindi", "Committee Chowk", 33.6000, 73.0600, "M", ["Nephrology", "Urology"]),
    ("Noor Charitable Eye Hospital", "semi_government", "Islamabad", "G-9", 33.6930, 73.0300, "M", ["Ophthalmology"]),
    ("Hope Cancer Care Trust", "semi_government", "Islamabad", "H-8", 33.6830, 73.0560, "L", ["Oncology"]),
    ("Margalla Heart & Vascular Institute", "private", "Islamabad", "F-8", 33.7110, 73.0350, "L", ["Cardiology", "General Surgery"]),
    ("Blue Area Medical Complex", "private", "Islamabad", "Blue Area", 33.7100, 73.0600, "L", ["Cardiology", "Oncology", "Neurology", "Orthopedics", "Gastroenterology", "Urology", "Gynecology", "Ophthalmology", "General Surgery", "Nephrology"]),
    ("Zarghoon Specialty Hospital", "private", "Islamabad", "F-6", 33.7295, 73.0775, "M", ["Orthopedics", "Neurology", "Gastroenterology", "General Surgery"]),
    ("Kohsar Care Hospital", "private", "Islamabad", "F-7", 33.7215, 73.0560, "M", ["Gynecology", "General Surgery", "Ophthalmology", "Urology"]),
    ("Serene Valley Hospital", "private", "Islamabad", "G-6", 33.7180, 73.0870, "L", ["Cardiology", "Nephrology", "Gastroenterology", "Urology"]),
    ("Islamabad Spine & Joint Hospital", "private", "Islamabad", "G-10", 33.6800, 73.0200, "M", ["Orthopedics", "Neurology"]),
    ("Crescent Oncology & Research Hospital", "private", "Islamabad", "I-8", 33.6650, 73.0750, "L", ["Oncology", "Gastroenterology"]),
    ("PWD Family Medical Centre", "private", "Islamabad", "PWD", 33.5800, 73.1450, "S", ["Gynecology", "General Surgery", "Orthopedics"]),
    ("DHA Specialty Hospital", "private", "Rawalpindi", "DHA Phase 2", 33.5290, 73.1200, "L", ["Cardiology", "Orthopedics", "General Surgery", "Urology", "Gynecology"]),
    ("Bahria Town Medical Centre", "private", "Rawalpindi", "Bahria Town", 33.5400, 73.1100, "M", ["Cardiology", "Neurology", "Gynecology", "General Surgery", "Ophthalmology"]),
    ("Gulzar-e-Quaid Family Hospital", "private", "Rawalpindi", "Gulzar-e-Quaid", 33.5870, 73.1250, "S", ["Gynecology", "General Surgery", "Orthopedics", "Ophthalmology"]),
    ("Satellite Town Kidney & Urology Hospital", "private", "Rawalpindi", "Satellite Town", 33.6370, 73.0700, "M", ["Nephrology", "Urology"]),
    ("Peshawar Road Neuro Centre", "private", "Rawalpindi", "Peshawar Road", 33.6000, 73.0100, "M", ["Neurology", "Orthopedics", "General Surgery"]),
    ("Faizabad Gastro & Liver Centre", "private", "Rawalpindi", "Faizabad", 33.6620, 73.0830, "M", ["Gastroenterology", "General Surgery"]),
    ("Attock District Hospital", "government", "Attock", "Attock", 33.7660, 72.3600, "M", ["General Surgery", "Gynecology", "Orthopedics"]),
    ("Golra Eye Hospital", "private", "Islamabad", "Golra", 33.7000, 72.9800, "S", ["Ophthalmology"]),
    ("Adiala Road Heart Centre", "private", "Rawalpindi", "Adiala Road", 33.5500, 73.0600, "M", ["Cardiology", "General Surgery"]),
]

FIRST = ["Ayesha", "Bilal", "Farhan", "Hina", "Imran", "Kamran", "Maryam", "Naveed", "Omar", "Rabia", "Saad", "Tariq", "Uzma", "Waqar", "Zainab"]
LAST = ["Khan", "Ahmed", "Malik", "Raza", "Siddiqui", "Qureshi", "Butt", "Chaudhry", "Hussain", "Javed"]
FAC_BASE = ["Pharmacy", "Laboratory", "Parking"]
FAC_MID = ["Ambulance", "ICU", "Blood Bank"]
FAC_BIG = ["MRI / CT Scan", "Cath Lab", "Operation Theatres"]

TREAT_BY_CAT = {}
for t in TREATMENTS:
    TREAT_BY_CAT.setdefault(t[1], []).append(t)


def r500(x):
    return int(round(x / 500.0) * 500)


hospitals = []
for i, (name, typ, city, area, lat, lng, size, depts) in enumerate(H, 1):
    mult = {"government": rng.uniform(0.10, 0.20), "semi_government": rng.uniform(0.22, 0.38),
            "private": rng.uniform(0.85, 1.35)}[typ]
    treats, prices, doctors = [], [], []
    for d in depts:
        for (tn, cat, base, adv, _) in TREAT_BY_CAT[d]:
            if adv and size == "S":
                continue
            status = "limited" if (adv and size == "M") else "available"
            treats.append({"name": tn, "status": status})
            lo = base * mult * rng.uniform(0.85, 0.95)
            prices.append({"treatment": tn, "min": r500(lo), "max": r500(lo * rng.uniform(1.2, 1.45))})
    for d in depts[:2]:
        doctors.append({"name": f"Dr. {rng.choice(FIRST)} {rng.choice(LAST)}", "specialization": CATEGORIES[d],
                        "status": "limited" if rng.random() < 0.2 else "available"})
    facilities = FAC_BASE + (FAC_MID if size in "ML" else []) + (FAC_BIG if size == "L" else [])
    progs = []
    for p, ptype, _ in PROGRAMS:
        if typ == "government":
            acc = {"government_card": 0.9, "insurance": 0.15, "zakat": 0.7, "welfare": 0.8, "aid": 0.6}[ptype]
        elif typ == "semi_government":
            acc = {"government_card": 0.7, "insurance": 0.6, "zakat": 0.6, "welfare": 0.9, "aid": 0.4}[ptype]
        else:
            acc = {"government_card": 0.35, "insurance": 0.8, "zakat": 0.05, "welfare": 0.15, "aid": 0.05}[ptype]
        x = rng.random()
        progs.append({"program": p, "status": "accepted" if x < acc else ("unknown" if x < acc + 0.08 else "not_accepted")})
    hospitals.append({
        "name": f"{name} (Demo)", "type": typ, "address": f"{area}, {city} (approximate demo location)", "city": city,
        "lat": lat, "lng": lng, "contact": f"051-000{i:04d} (demo number)", "website": None,
        "hours": ("24/7 emergency; OPD Mon-Sat 8:00-14:00" if size != "S" else "Mon-Sat 9:00-17:00") + " (unverified)",
        "facilities": facilities, "emergency": size in "ML", "treatments": treats, "doctors": doctors, "prices": prices, "programs": progs,
    })

data = {
    "meta": {"data_source": "demo", "synthetic": True,
             "disclaimer": "SYNTHETIC DEMO DATA. Hospital names are fictional; coordinates are approximate fixed area locations; prices, doctors, scheme acceptance and availability are invented for demonstration and are NOT verified."},
    "treatments": [{"name": n, "category": c, "description": d, "specialist": CATEGORIES[c]} for (n, c, _, _, d) in TREATMENTS],
    "programs": [{"name": n, "type": t, "description": d} for (n, t, d) in PROGRAMS],
    "hospitals": hospitals,
}
out = Path(__file__).with_name("demo_hospitals.json")
out.write_text(json.dumps(data, indent=1, ensure_ascii=False))
print(f"{len(hospitals)} hospitals, {len(TREATMENTS)} treatments, {sum(len(h['doctors']) for h in hospitals)} doctors -> {out}")
