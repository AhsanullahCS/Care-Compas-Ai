import { useSearch } from "../context/SearchContext";
import { TYPE_LABEL } from "../utils/format";

const chip = (on) => `rounded-full border px-2.5 py-1 text-xs font-semibold ${on ? "border-teal-600 bg-teal-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-teal-400"}`;

export default function FilterPanel() {
  const { params, update, meta } = useSearch();
  if (!meta) return null;
  const toggle = (key, v) => update({ [key]: params[key].includes(v) ? params[key].filter((x) => x !== v) : [...params[key], v] });
  return (
    <div className="space-y-3 text-sm">
      <div className="grid grid-cols-2 gap-2">
        <div><label className="mb-1 block text-xs font-semibold text-slate-600">Treatment</label>
          <select className="w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm" value={params.treatment_id} onChange={(e) => update({ treatment_id: e.target.value, condition: "", specialist: "", query: "" })}>
            <option value="">All hospitals</option>
            {meta.categories.map((c) => <optgroup key={c} label={c}>{meta.treatments.filter((t) => t.category === c).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</optgroup>)}
          </select></div>
        <div><label className="mb-1 block text-xs font-semibold text-slate-600">Radius</label>
          <select className="w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm" value={params.radius_km} onChange={(e) => update({ radius_km: Number(e.target.value) })}>{meta.radii.map((r) => <option key={r} value={r}>{r} km</option>)}</select></div>
      </div>
      <div><p className="mb-1 text-xs font-semibold text-slate-600">Hospital type</p>
        <div className="flex flex-wrap gap-1.5">{meta.hospital_types.map((t) => <button key={t} aria-pressed={params.hospital_types.includes(t)} className={chip(params.hospital_types.includes(t))} onClick={() => toggle("hospital_types", t)}>{TYPE_LABEL[t]}</button>)}</div></div>
      <div><p className="mb-1 text-xs font-semibold text-slate-600">Healthcare program accepted</p>
        <div className="flex flex-wrap gap-1.5">{meta.programs.map((p) => <button key={p.id} aria-pressed={params.program_ids.includes(p.id)} className={chip(params.program_ids.includes(p.id))} onClick={() => toggle("program_ids", p.id)}>{p.name}</button>)}</div></div>
      <div className="grid grid-cols-2 items-end gap-2">
        <div><label className="mb-1 block text-xs font-semibold text-slate-600">Max budget (PKR){!params.treatment_id && " – pick a treatment"}</label>
          <input type="number" min="0" step="1000" disabled={!params.treatment_id} className="w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm disabled:bg-slate-50" placeholder="e.g. 100000" value={params.max_budget} onChange={(e) => update({ max_budget: e.target.value })} /></div>
        <label className="flex items-center gap-2 pb-1.5 text-xs font-semibold text-slate-600"><input type="checkbox" checked={params.financial_assistance} onChange={(e) => update({ financial_assistance: e.target.checked })} />Financial aid listed</label>
      </div>
      <div><label className="mb-1 block text-xs font-semibold text-slate-600">Sort by</label>
        <select className="w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm" value={params.sort} onChange={(e) => update({ sort: e.target.value })}>{meta.sort_options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select></div>
    </div>
  );
}
