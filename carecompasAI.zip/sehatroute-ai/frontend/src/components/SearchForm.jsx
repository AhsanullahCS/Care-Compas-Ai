import { LocateFixed, Search } from "lucide-react";
import { useSearch } from "../context/SearchContext";

const field = "w-full rounded-xl border border-slate-200 bg-white px-3 py-2 text-sm focus:border-teal-500";
const Label = ({ children }) => <label className="mb-1 block text-xs font-semibold text-slate-600">{children}</label>;

export default function SearchForm({ onSubmit }) {
  const { params, update, meta, locate, geoMsg, loading } = useSearch();
  if (!meta) return <p className="p-4 text-sm text-slate-500">Loading search options…</p>;
  const setArea = (name) => { const a = meta.areas.find((x) => x.name === name); if (a) update({ lat: a.lat, lng: a.lng, locationLabel: a.name, locationSource: "preset" }); };
  const toggleProgram = (id) => update({ program_ids: params.program_ids.includes(id) ? params.program_ids.filter((x) => x !== id) : [...params.program_ids, id] });

  return (
    <form onSubmit={(e) => { e.preventDefault(); onSubmit(); }} className="space-y-3 rounded-2xl border border-slate-200 bg-white p-4 shadow-soft">
      <div className="grid gap-3 sm:grid-cols-2">
        <div><Label>Medical condition or referral text</Label><input className={field} placeholder="e.g. heart disease, referred for angioplasty" value={params.condition} onChange={(e) => update({ condition: e.target.value })} /></div>
        <div><Label>Required treatment</Label>
          <select className={field} value={params.treatment_id} onChange={(e) => update({ treatment_id: e.target.value })}>
            <option value="">Any / not sure</option>
            {meta.categories.map((c) => <optgroup key={c} label={c}>{meta.treatments.filter((t) => t.category === c).map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</optgroup>)}
          </select></div>
        <div><Label>Specialist</Label>
          <select className={field} value={params.specialist} onChange={(e) => update({ specialist: e.target.value })}>
            <option value="">Any</option>{meta.specialists.map((s) => <option key={s}>{s}</option>)}
          </select></div>
        <div><Label>City or area</Label>
          <div className="flex gap-2">
            <select className={field} value={params.locationSource === "gps" ? "" : params.locationLabel} onChange={(e) => setArea(e.target.value)}>
              {params.locationSource === "gps" && <option value="">My current location</option>}
              {meta.areas.map((a) => <option key={a.name}>{a.name}</option>)}
            </select>
            <button type="button" onClick={locate} title="Use my current location" className="shrink-0 rounded-xl border border-teal-600 px-3 text-teal-700 hover:bg-teal-50"><LocateFixed size={18} /><span className="sr-only">Use current location</span></button>
          </div>
          {geoMsg && <p className="mt-1 text-xs text-amber-700">{geoMsg}</p>}
        </div>
        <div><Label>Search radius</Label>
          <select className={field} value={params.radius_km} onChange={(e) => update({ radius_km: Number(e.target.value) })}>{meta.radii.map((r) => <option key={r} value={r}>{r} km</option>)}</select></div>
        <div><Label>My healthcare card / insurance</Label>
          <div className="flex flex-wrap gap-1.5">{meta.programs.map((p) => (
            <button type="button" key={p.id} onClick={() => toggleProgram(p.id)} aria-pressed={params.program_ids.includes(p.id)}
              className={`rounded-full border px-2.5 py-1 text-xs font-semibold ${params.program_ids.includes(p.id) ? "border-green-600 bg-green-600 text-white" : "border-slate-200 bg-white text-slate-600 hover:border-green-400"}`}>{p.name}</button>))}</div></div>
      </div>
      <button disabled={loading} className="inline-flex w-full items-center justify-center gap-2 rounded-xl bg-teal-600 px-4 py-2.5 font-bold text-white hover:bg-teal-700 disabled:opacity-60 sm:w-auto"><Search size={16} />{loading ? "Searching…" : "Find healthcare"}</button>
    </form>
  );
}
