import { Link } from "react-router-dom";
import { Award, Banknote, MapPin, ShieldCheck } from "lucide-react";
import { pkr, priceRange } from "../utils/format";

const Item = ({ icon: Icon, label, h, color }) => h ? (
  <Link to={`/hospitals/${h.id}`} className="flex gap-3 rounded-xl border border-slate-200 bg-white p-3 hover:border-teal-400">
    <span className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${color}`}><Icon size={18} /></span>
    <span className="min-w-0 text-sm"><span className="block text-xs font-semibold text-slate-500">{label}</span><b className="block truncate text-navy">{h.name}</b>
      <span className="text-xs text-slate-500">{h.distance_km} km{h.price ? ` · ${priceRange(h.price)}` : ""} · score {Math.round(h.score)}</span></span>
  </Link>) : null;

export function ComparisonPanel({ comparison }) {
  if (!comparison || !comparison.eligible_count) return null;
  return (
    <section className="space-y-3 rounded-2xl border border-slate-200 bg-slate-50 p-4">
      <h2 className="font-bold text-navy">Smart cost comparison <span className="text-xs font-medium text-slate-500">· {comparison.eligible_count} eligible hospitals</span></h2>
      <div className="grid gap-2 sm:grid-cols-2">
        <Item icon={Award} label="Best overall match" h={comparison.best_match} color="bg-teal-100 text-teal-700" />
        <Item icon={Banknote} label="Lowest estimated cost" h={comparison.lowest_cost} color="bg-green-100 text-green-700" />
        <Item icon={MapPin} label="Nearest eligible hospital" h={comparison.nearest} color="bg-blue-100 text-blue-700" />
        <Item icon={ShieldCheck} label="With financial support listed" h={comparison.with_financial_support} color="bg-green-100 text-green-700" />
      </div>
      {comparison.note && <p className="text-xs text-slate-500">{comparison.note}</p>}
    </section>
  );
}

export function SavingsCalculator({ comparison }) {
  const s = comparison?.savings;
  if (!s) return null;
  return (
    <section className="rounded-2xl border border-green-200 bg-green-50 p-4">
      <h2 className="font-bold text-green-900">Patient savings calculator</h2>
      <p className="text-xs text-green-800">{s.treatment} — estimates across eligible hospitals</p>
      <dl className="mt-3 space-y-1.5 text-sm">
        {s.avg_private_estimate != null && <>
          <div className="flex justify-between"><dt>Average private estimate</dt><dd className="font-semibold">{pkr(s.avg_private_estimate)}</dd></div>
          <div className="flex justify-between"><dt>Lowest govt / trust estimate</dt><dd className="font-semibold">{pkr(s.lowest_supported_estimate)}</dd></div>
          <div className="flex justify-between border-t border-green-200 pt-1.5 text-green-800"><dt>Potential difference</dt><dd className="text-lg font-extrabold">{pkr(s.private_vs_supported_difference)}</dd></div></>}
        <div className="flex justify-between text-xs text-green-900"><dt>Highest vs lowest estimate overall</dt><dd className="font-bold">{pkr(s.potential_difference)}</dd></div>
      </dl>
      <p className="mt-2 text-xs text-green-900/80">{comparison.disclaimer}</p>
    </section>
  );
}
