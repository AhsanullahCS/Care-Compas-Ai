import { useState } from "react";
import { Link, useNavigate } from "react-router-dom";
import { Building2, ChevronDown, Heart, MapPin, Navigation, Phone, ShieldCheck, Stethoscope } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { acceptedPrograms, directionsUrl, priceRange } from "../utils/format";
import { DataBadge, ScoreBadge, ScoreBreakdown, TypeBadge } from "./ui";

export default function HospitalCard({ h, from, selected, compact, onSelect }) {
  const { user, savedIds, toggleSave } = useAuth();
  const nav = useNavigate();
  const [open, setOpen] = useState(false);
  const saved = savedIds.has(h.id);
  const accepted = acceptedPrograms(h);
  const docs = h.specialists.filter((s) => s.availability !== "unavailable");

  const save = async (e) => {
    e.stopPropagation();
    if (!user) return nav("/login");
    try { await toggleSave(h.id); } catch { /* ignore */ }
  };

  return (
    <article id={`hosp-${h.id}`} onClick={onSelect} className={`rounded-2xl border bg-white shadow-soft transition ${onSelect ? "cursor-pointer" : ""} ${selected ? "border-red-400 ring-2 ring-red-300" : "border-slate-200 hover:border-teal-300"}`}>
      <div className="flex gap-3 p-4">
        {!compact && <div className="hidden h-20 w-20 shrink-0 items-center justify-center rounded-xl bg-gradient-to-br from-navy to-teal-500 text-white sm:flex"><Building2 size={30} /></div>}
        <div className="min-w-0 flex-1">
          <div className="flex items-start justify-between gap-2">
            <h3 className="font-bold leading-tight text-navy">{h.name}</h3>
            <ScoreBadge score={h.score} />
          </div>
          <div className="mt-1.5 flex flex-wrap items-center gap-1.5"><TypeBadge type={h.hospital_type} /><DataBadge h={h} />
            {h.financial_assistance && <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-semibold text-green-800"><ShieldCheck size={12} />Financial support listed</span>}
          </div>
          <p className="mt-2 flex items-center gap-1 text-sm text-slate-600"><MapPin size={14} className="shrink-0 text-teal-600" /> <b>{h.distance_km} km</b> · {h.address}</p>
          {!h.location_verified && <p className="text-xs text-amber-700">Demo location (approximate) — not verified</p>}
        </div>
      </div>

      <div className="space-y-2 border-t border-slate-100 px-4 py-3 text-sm">
        {h.price ? (
          <p><span className="text-slate-500">{h.price.treatment}:</span> <b className="text-green-700">{priceRange(h.price)}</b> <span className="text-xs text-slate-400">{h.price.verified ? "(verified)" : "(demo estimate)"}</span></p>
        ) : <p className="text-xs text-slate-400">{h.flags.includes("price_unavailable") ? "Price not available for this treatment" : "Select a specific treatment to see cost estimates"}</p>}
        {h.matched_treatments.length > 0 && <p className="flex gap-1.5"><Stethoscope size={14} className="mt-0.5 shrink-0 text-teal-600" /><span>{h.matched_treatments.map((t) => t.name + (t.status === "limited" ? " (limited)" : "")).join(", ")}</span></p>}
        {!compact && docs.length > 0 && <p className="text-xs text-slate-500">Specialists listed: {docs.map((d) => `${d.name} – ${d.specialization}${d.availability === "limited" ? " (limited)" : ""}`).join("; ")}</p>}
        <p className="text-xs text-slate-600">Cards / aid: {accepted.length ? accepted.map((p) => p.name).join(", ") + (accepted.some((p) => !p.verified) ? " (unverified)" : "") : "none listed"}</p>
        {!compact && <p className="text-xs text-slate-500">Hours: {h.operating_hours || "not listed"}{!h.hours_verified && h.operating_hours ? "" : ""} · Status: availability not live-verified</p>}
        {!compact && <p className="text-xs text-slate-500">Facilities: {h.facilities.join(", ") || "—"}</p>}
      </div>

      <div className="px-4 pb-3">
        <button onClick={(e) => { e.stopPropagation(); setOpen(!open); }} className="flex items-center gap-1 text-xs font-semibold text-teal-700"><ChevronDown size={14} className={open ? "rotate-180" : ""} /> Why this score?</button>
        {open && <div className="mt-2 space-y-2"><p className="rounded-lg bg-teal-50 p-2.5 text-xs text-teal-900">{h.explanation}</p><ScoreBreakdown breakdown={h.breakdown} /></div>}
      </div>

      <div className="flex flex-wrap gap-2 border-t border-slate-100 p-3 text-sm" onClick={(e) => e.stopPropagation()}>
        <Link to={`/hospitals/${h.id}`} className="rounded-lg bg-navy px-3 py-1.5 font-semibold text-white hover:bg-navy-dark">View Details</Link>
        <a href={directionsUrl(h, from)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 font-medium hover:bg-slate-50"><Navigation size={14} />Directions</a>
        {h.contact && <a href={`tel:${h.contact.replace(/[^+\d]/g, "")}`} className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 font-medium hover:bg-slate-50"><Phone size={14} />Contact</a>}
        <button onClick={save} aria-pressed={saved} className={`ml-auto inline-flex items-center gap-1 rounded-lg border px-3 py-1.5 font-medium ${saved ? "border-red-200 bg-red-50 text-red-600" : "border-slate-200 hover:bg-slate-50"}`}><Heart size={14} fill={saved ? "currentColor" : "none"} />{saved ? "Saved" : "Save"}</button>
      </div>
    </article>
  );
}
