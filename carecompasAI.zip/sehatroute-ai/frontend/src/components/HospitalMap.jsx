import { useEffect, useRef } from "react";
import L from "leaflet";
import "leaflet/dist/leaflet.css";
import "leaflet.markercluster";
import "leaflet.markercluster/dist/MarkerCluster.css";
import "leaflet.markercluster/dist/MarkerCluster.Default.css";
import { acceptedPrograms, priceRange, TYPE_LABEL } from "../utils/format";

const esc = (s) => String(s ?? "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));

// Red hospital pin. Small badge: amber "D" = demo (approximate) location, green check = verified location.
const pin = (verified) => `<svg viewBox="0 0 30 42" width="30" height="42" aria-hidden="true">
<path d="M15 0C6.7 0 0 6.7 0 15c0 11 15 27 15 27s15-16 15-27C30 6.7 23.3 0 15 0z" fill="#DC2626" stroke="#fff" stroke-width="2"/>
<circle cx="15" cy="15" r="6" fill="#fff"/><path d="M15 11v8M11 15h8" stroke="#DC2626" stroke-width="2.2"/>
<circle cx="25" cy="6" r="6" fill="${verified ? "#16A34A" : "#F59E0B"}" stroke="#fff" stroke-width="1.5"/>
<text x="25" y="9.2" font-size="8.5" font-weight="700" text-anchor="middle" fill="#fff" font-family="sans-serif">${verified ? "✓" : "D"}</text></svg>`;

const hospitalIcon = (h, selected) => L.divIcon({ className: `sr-marker${selected ? " sel" : ""}`, html: pin(h.location_verified), iconSize: [30, 42], iconAnchor: [15, 42], popupAnchor: [0, -38] });
const userIcon = L.divIcon({ className: "sr-user", html: '<div class="dot"></div>', iconSize: [18, 18], iconAnchor: [9, 9] });

function popupEl(h, onDetails) {
  const acc = acceptedPrograms(h);
  const treat = h.price?.treatment || h.matched_treatments?.[0]?.name || null;
  const el = document.createElement("div");
  el.innerHTML = `
    <div style="font-weight:800;color:#0B3A6F;font-size:14px;line-height:1.25">${esc(h.name)}</div>
    <div style="margin:4px 0;font-size:11px">
      <span style="background:#e0f2fe;color:#075985;border-radius:9999px;padding:1px 8px;font-weight:600">${esc(TYPE_LABEL[h.hospital_type] || h.hospital_type)}</span>
      <span style="margin-left:4px;border-radius:9999px;padding:1px 8px;font-weight:600;background:${h.location_verified ? "#dcfce7" : "#fef3c7"};color:${h.location_verified ? "#166534" : "#92400e"}">${h.location_verified ? "Verified location" : "Demo location (approx.)"}</span>
    </div>
    <table style="font-size:12px;line-height:1.5;width:100%"><tbody>
      <tr><td style="color:#64748b;padding-right:8px">Distance</td><td><b>${esc(h.distance_km)} km</b></td></tr>
      <tr><td style="color:#64748b">Treatment</td><td>${treat ? esc(treat) : '<i style="color:#94a3b8">Select a treatment</i>'}</td></tr>
      <tr><td style="color:#64748b">Est. cost</td><td>${h.price ? `<b style="color:#15803d">${esc(priceRange(h.price))}</b> <span style="color:#94a3b8">(${h.price.verified ? "verified" : "demo est."})</span>` : '<span style="color:#94a3b8">—</span>'}</td></tr>
      <tr><td style="color:#64748b">Cards</td><td>${acc.length ? esc(acc.slice(0, 2).map((p) => p.name).join(", ")) + (acc.length > 2 ? ` +${acc.length - 2}` : "") + (acc.some((p) => !p.verified) ? ' <span style="color:#94a3b8">(unverified)</span>' : "") : '<span style="color:#94a3b8">none listed</span>'}</td></tr>
      <tr><td style="color:#64748b">AI score</td><td><b style="background:#0d9488;color:#fff;border-radius:6px;padding:0 6px">${Math.round(h.score)}/100</b></td></tr>
    </tbody></table>
    <button type="button" style="margin-top:8px;width:100%;background:#0B3A6F;color:#fff;border:0;border-radius:8px;padding:6px 0;font-weight:700;cursor:pointer">View Details</button>`;
  el.querySelector("button").addEventListener("click", () => onDetails(h.id));
  return el;
}

export default function HospitalMap({ user, radiusKm, hospitals, selectedId, onSelect, onDetails, single = false }) {
  const box = useRef(null);
  const map = useRef(null);
  const cluster = useRef(null);
  const markers = useRef({});
  const userRef = useRef(user);
  const userLayer = useRef(null);
  const circle = useRef(null);
  const cb = useRef({});
  const lastSel = useRef(null);
  cb.current = { onSelect, onDetails };
  userRef.current = user;

  useEffect(() => {
    const m = L.map(box.current, { zoomControl: false }).setView([user.lat, user.lng], 11);
    L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png", { maxZoom: 19, attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors' }).addTo(m);
    L.control.zoom({ position: "topright" }).addTo(m);
    const locate = L.control({ position: "topright" });
    locate.onAdd = () => {
      const wrap = L.DomUtil.create("div", "leaflet-bar");
      const a = L.DomUtil.create("a", "sr-locate", wrap);
      a.href = "#"; a.title = "Return to my location"; a.setAttribute("role", "button"); a.setAttribute("aria-label", "Return to my location");
      a.innerHTML = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#2563eb" stroke-width="2.2" stroke-linecap="round"><circle cx="12" cy="12" r="3"/><circle cx="12" cy="12" r="8"/><path d="M12 1v3M12 20v3M1 12h3M20 12h3"/></svg>';
      L.DomEvent.disableClickPropagation(wrap);
      L.DomEvent.on(a, "click", (e) => { L.DomEvent.preventDefault(e); m.setView([userRef.current.lat, userRef.current.lng], Math.max(m.getZoom(), 12)); });
      return wrap;
    };
    locate.addTo(m);
    const legend = L.control({ position: "bottomleft" });
    legend.onAdd = () => {
      const d = L.DomUtil.create("div");
      d.style.cssText = "background:#fff;padding:6px 10px;border-radius:10px;font:600 11px Manrope,sans-serif;box-shadow:0 2px 8px rgba(0,0,0,.2);line-height:1.7";
      d.innerHTML = '<div><span style="display:inline-block;width:10px;height:10px;border-radius:9999px;background:#2563eb;margin-right:6px"></span>You</div><div><span style="display:inline-block;width:10px;height:10px;border-radius:9999px;background:#DC2626;margin-right:6px"></span>Hospital</div><div><span style="display:inline-block;width:10px;height:10px;border-radius:9999px;background:#F59E0B;margin-right:6px"></span>D = demo location</div><div><span style="display:inline-block;width:10px;height:10px;border-radius:9999px;background:#16A34A;margin-right:6px"></span>✓ = verified location</div>';
      return d;
    };
    if (!single) legend.addTo(m);
    cluster.current = L.markerClusterGroup({ showCoverageOnHover: false, maxClusterRadius: 45, spiderfyOnMaxZoom: true });
    m.addLayer(cluster.current);
    map.current = m;
    const ro = new ResizeObserver(() => { if (map.current === m) m.invalidateSize(); });
    ro.observe(box.current);
    return () => { ro.disconnect(); m.remove(); map.current = null; cluster.current = null; userLayer.current = null; circle.current = null; markers.current = {}; lastSel.current = null; };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // user position + radius circle; refit when location or radius changes
  useEffect(() => {
    const m = map.current; if (!m) return;
    if (single) { if (hospitals[0]) m.setView([hospitals[0].latitude, hospitals[0].longitude], 15); return; }
    const ll = [user.lat, user.lng];
    if (userLayer.current) userLayer.current.setLatLng(ll); else userLayer.current = L.marker(ll, { icon: userIcon, zIndexOffset: 2000, keyboard: false }).bindTooltip("You are here").addTo(m);
    if (circle.current) { circle.current.setLatLng(ll); circle.current.setRadius(radiusKm * 1000); }
    else circle.current = L.circle(ll, { radius: radiusKm * 1000, color: "#2563eb", weight: 1.5, fillOpacity: 0.04, interactive: false }).addTo(m);
    m.fitBounds(circle.current.getBounds(), { padding: [20, 20], animate: false, maxZoom: 14 });
  }, [user.lat, user.lng, radiusKm, single, hospitals]);

  // hospital markers (real DB coordinates only)
  useEffect(() => {
    const g = cluster.current; if (!g) return;
    g.clearLayers(); markers.current = {};
    hospitals.forEach((h) => {
      const mk = L.marker([h.latitude, h.longitude], { icon: hospitalIcon(h, false), title: h.name, riseOnHover: true });
      if (!single) mk.bindPopup(() => popupEl(h, (id) => cb.current.onDetails(id)), { maxWidth: 280 });
      mk.on("click", () => cb.current.onSelect(h.id));
      markers.current[h.id] = { mk, h };
      g.addLayer(mk);
    });
    lastSel.current = null;
  }, [hospitals]);

  // highlight selected marker + open popup (zooming/spiderfying out of a cluster when needed)
  useEffect(() => {
    const g = cluster.current; if (!g) return;
    const prev = lastSel.current && markers.current[lastSel.current];
    if (prev) prev.mk.setIcon(hospitalIcon(prev.h, false));
    lastSel.current = null;
    const cur = selectedId != null && markers.current[selectedId];
    if (!cur) return;
    cur.mk.setIcon(hospitalIcon(cur.h, true));
    lastSel.current = selectedId;
    if (!single) g.zoomToShowLayer(cur.mk, () => { if (!cur.mk.isPopupOpen()) cur.mk.openPopup(); });
  }, [selectedId, hospitals]);

  return <div ref={box} className="h-full w-full" role="application" aria-label="Interactive hospital map" />;
}
