import { AlertTriangle, BadgeCheck, FlaskConical, Phone } from "lucide-react";
import { FACTOR_LABEL, TYPE_LABEL, TYPE_STYLE } from "../utils/format";

export const TypeBadge = ({ type }) => (
  <span className={`rounded-full px-2.5 py-0.5 text-xs font-semibold ${TYPE_STYLE[type] || "bg-slate-100"}`}>{TYPE_LABEL[type] || type}</span>
);

export const DataBadge = ({ h }) =>
  h.verification_status === "verified" ? (
    <span className="inline-flex items-center gap-1 rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-semibold text-green-800"><BadgeCheck size={12} /> Verified</span>
  ) : (
    <span title="Synthetic demo data — not verified" className="inline-flex items-center gap-1 rounded-full bg-amber-100 px-2.5 py-0.5 text-xs font-semibold text-amber-800"><FlaskConical size={12} /> Demo data</span>
  );

export const EmergencyNotice = ({ className = "" }) => (
  <div role="note" className={`flex items-start gap-2 rounded-xl border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-800 ${className}`}>
    <Phone size={16} className="mt-0.5 shrink-0" />
    <p><b>Medical emergency?</b> Call your local emergency service now (Pakistan: Rescue 1122 or Edhi 115) or go to the nearest emergency department. Don't wait to search here. SehatRoute AI does not diagnose or replace a doctor.</p>
  </div>
);

export const ErrorBox = ({ children }) => children ? (
  <div role="alert" className="flex items-start gap-2 rounded-xl border border-amber-300 bg-amber-50 px-4 py-3 text-sm text-amber-900"><AlertTriangle size={16} className="mt-0.5 shrink-0" />{children}</div>
) : null;

export const ScoreBadge = ({ score, big }) => {
  const c = score >= 75 ? "bg-green-600" : score >= 50 ? "bg-teal-600" : "bg-slate-500";
  return <span className={`inline-flex items-center justify-center rounded-lg font-bold text-white ${c} ${big ? "px-3 py-1.5 text-lg" : "px-2 py-0.5 text-xs"}`}>{Math.round(score)}<span className="font-medium opacity-80">/100</span></span>;
};

export function ScoreBreakdown({ breakdown }) {
  return (
    <div className="space-y-1.5">
      {Object.entries(breakdown || {}).map(([k, v]) => (
        <div key={k} className="text-xs">
          <div className="flex justify-between text-slate-600"><span>{FACTOR_LABEL[k] || k} <span className="text-slate-400">({v.weight}% weight)</span></span><b>{Math.round(v.score)}</b></div>
          <div className="h-1.5 rounded-full bg-slate-100"><div className="h-1.5 rounded-full bg-teal-500" style={{ width: `${v.score}%` }} /></div>
        </div>
      ))}
    </div>
  );
}

export const Spinner = ({ label = "Loading…" }) => (
  <div className="flex items-center gap-2 p-4 text-sm text-slate-500" role="status"><span className="h-4 w-4 animate-spin rounded-full border-2 border-teal-600 border-t-transparent" />{label}</div>
);
