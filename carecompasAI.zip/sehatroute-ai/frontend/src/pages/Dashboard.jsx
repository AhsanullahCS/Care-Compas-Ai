import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Clock, Heart, Sparkles } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useSearch } from "../context/SearchContext";
import { get } from "../services/api";
import SearchForm from "../components/SearchForm";
import HospitalCard from "../components/HospitalCard";
import { ComparisonPanel, SavingsCalculator } from "../components/Comparison";
import { EmergencyNotice, ErrorBox, Spinner } from "../components/ui";

export default function Dashboard() {
  const { user, savedIds } = useAuth();
  const { params, update, run, data, loading, error, meta } = useSearch();
  const [shown, setShown] = useState(8);
  const [saved, setSaved] = useState([]);
  const [recent, setRecent] = useState([]);
  const [searched, setSearched] = useState(!!data);

  const load = () => { setShown(8); setSearched(true); run(params).then(() => user && get("/search/history").then(setRecent).catch(() => {})); };
  useEffect(() => { if (user) { get("/saved-hospitals").then(setSaved).catch(() => {}); get("/search/history").then(setRecent).catch(() => {}); } }, [user, savedIds]);
  // re-sort without a full form submit
  useEffect(() => { if (searched) run(params); /* eslint-disable-next-line */ }, [params.sort]);

  const from = { lat: params.lat, lng: params.lng };
  const results = data?.results || [];
  const ex = data?.query?.extraction;

  return (
    <div className="mx-auto max-w-7xl space-y-5 px-4 py-6">
      <div><h1 className="text-2xl font-extrabold text-navy">Find healthcare</h1><p className="text-sm text-slate-500">Search by condition, treatment or specialist. Only hospitals that offer the treatment are ranked.</p></div>
      <EmergencyNotice />
      <SearchForm onSubmit={load} />
      <ErrorBox>{error}</ErrorBox>

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-4 lg:col-span-2">
          {loading && <Spinner label="Ranking hospitals…" />}
          {!searched && !loading && <div className="rounded-2xl border border-dashed border-slate-300 p-10 text-center text-slate-500"><Sparkles className="mx-auto mb-2 text-teal-600" />Choose a treatment, specialist or describe your referral, then press <b>Find healthcare</b>.</div>}
          {data && (<>
            <div className="flex flex-wrap items-center justify-between gap-2">
              <p className="text-sm text-slate-600"><b>{data.total}</b> eligible hospital{data.total === 1 ? "" : "s"} within {data.query.radius_km} km of {params.locationLabel}
                {data.query.treatment && <> for <b>{data.query.treatment}</b></>}{!data.query.treatment && data.query.department && <> for <b>{data.query.department}</b></>}</p>
              {meta && <select aria-label="Sort results" className="rounded-lg border border-slate-200 px-2 py-1.5 text-sm" value={params.sort} onChange={(e) => update({ sort: e.target.value })}>{meta.sort_options.map((o) => <option key={o.value} value={o.value}>{o.label}</option>)}</select>}
            </div>
            {ex && <p className="rounded-xl bg-teal-50 p-3 text-sm text-teal-900">Understood from your text: <b>{ex.department || "—"}</b>{ex.specialist && <> · specialist <b>{ex.specialist}</b></>}{ex.treatment_names?.length > 0 && <> · treatment <b>{ex.treatment_names.join(", ")}</b></>} <span className="text-xs">({ex.method}; this is not a diagnosis)</span></p>}
            {data.message && <ErrorBox>{data.message}</ErrorBox>}
            <ComparisonPanel comparison={data.comparison} />
            <div className="space-y-4">{results.slice(0, shown).map((h) => <HospitalCard key={h.id} h={h} from={from} />)}</div>
            {shown < results.length && <button onClick={() => setShown(shown + 8)} className="w-full rounded-xl border border-slate-200 py-2.5 font-semibold text-navy hover:bg-slate-50">Show more ({results.length - shown} remaining)</button>}
            {results.length > 0 && <p className="text-center text-sm"><Link className="font-semibold text-teal-700" to="/map">View these hospitals on the interactive map →</Link></p>}
          </>)}
        </div>

        <aside className="space-y-4">
          <SavingsCalculator comparison={data?.comparison} />
          <section className="rounded-2xl border border-slate-200 p-4 shadow-soft">
            <h2 className="mb-2 flex items-center gap-2 font-bold text-navy"><Heart size={16} className="text-red-500" />Saved hospitals</h2>
            {!user ? <p className="text-sm text-slate-500"><Link className="font-semibold text-teal-700" to="/login">Log in</Link> to save hospitals.</p>
              : saved.length === 0 ? <p className="text-sm text-slate-500">Nothing saved yet.</p>
              : <ul className="space-y-1.5 text-sm">{saved.map((h) => <li key={h.id}><Link className="font-medium text-navy hover:underline" to={`/hospitals/${h.id}`}>{h.name}</Link></li>)}</ul>}
          </section>
          <section className="rounded-2xl border border-slate-200 p-4 shadow-soft">
            <h2 className="mb-2 flex items-center gap-2 font-bold text-navy"><Clock size={16} className="text-teal-600" />Recent searches</h2>
            {!user ? <p className="text-sm text-slate-500">Log in to keep your search history.</p>
              : recent.length === 0 ? <p className="text-sm text-slate-500">No searches yet.</p>
              : <ul className="space-y-1.5 text-sm">{recent.map((r) => <li key={r.id}><b>{r.search_query}</b><br /><span className="text-xs text-slate-400">{r.location}</span></li>)}</ul>}
          </section>
        </aside>
      </div>
    </div>
  );
}
