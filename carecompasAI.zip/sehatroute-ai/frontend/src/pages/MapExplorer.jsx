import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { List, Map as MapIcon, SlidersHorizontal } from "lucide-react";
import { useSearch } from "../context/SearchContext";
import HospitalMap from "../components/HospitalMap";
import HospitalCard from "../components/HospitalCard";
import FilterPanel from "../components/FilterPanel";
import { ErrorBox, Spinner } from "../components/ui";

export default function MapExplorer() {
  const { params, update, run, data, loading, error, locate, geoMsg } = useSearch();
  const nav = useNavigate();
  const [selectedId, setSelectedId] = useState(null);
  const [view, setView] = useState("map");
  const [showFilters, setShowFilters] = useState(false);
  const listRef = useRef(null);
  const asked = useRef(false);

  // 1) ask for the browser location once; falls back to the selected preset area
  useEffect(() => { if (!asked.current && params.locationSource !== "gps") { asked.current = true; locate(); } }, [locate, params.locationSource]);

  // 2) auto-update hospitals whenever radius, treatment, location or filters change
  const key = JSON.stringify([params.lat, params.lng, params.radius_km, params.treatment_id, params.specialist, params.condition, params.query, params.hospital_types, params.program_ids, params.max_budget, params.financial_assistance, params.sort]);
  useEffect(() => { const t = setTimeout(() => run(params), 250); return () => clearTimeout(t); /* eslint-disable-next-line */ }, [key]);

  const hospitals = data?.results || [];
  useEffect(() => { if (selectedId != null && !hospitals.some((h) => h.id === selectedId)) setSelectedId(null); }, [hospitals, selectedId]);
  const user = useMemo(() => ({ lat: params.lat, lng: params.lng }), [params.lat, params.lng]);

  // marker -> sidebar
  const fromMap = (id) => { setSelectedId(id); requestAnimationFrame(() => document.getElementById(`hosp-${id}`)?.scrollIntoView({ block: "nearest", behavior: "smooth" })); };
  // sidebar -> marker
  const fromList = (id) => { setSelectedId(id); if (window.innerWidth < 768) setView("map"); };

  const empty = !loading && data && hospitals.length === 0;
  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col md:flex-row">
      <div className="flex shrink-0 gap-2 border-b border-slate-200 bg-white p-2 md:hidden">
        {[["map", "Map", MapIcon], ["list", `List (${hospitals.length})`, List]].map(([v, l, I]) => (
          <button key={v} onClick={() => setView(v)} aria-pressed={view === v} className={`flex flex-1 items-center justify-center gap-1.5 rounded-lg py-2 text-sm font-semibold ${view === v ? "bg-navy text-white" : "bg-slate-100 text-slate-600"}`}><I size={15} />{l}</button>))}
      </div>

      <aside className={`${view === "list" ? "flex" : "hidden"} min-h-0 flex-1 flex-col border-r border-slate-200 bg-slate-50 md:flex md:w-[400px] md:flex-none`}>
        <div className="border-b border-slate-200 bg-white p-3">
          <div className="flex items-center justify-between">
            <p className="text-sm font-bold text-navy">{loading ? "Updating…" : `${data?.total ?? 0} hospitals`} <span className="font-medium text-slate-500">· {params.locationLabel}</span></p>
            <button onClick={() => setShowFilters(!showFilters)} aria-expanded={showFilters} className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-2.5 py-1 text-xs font-semibold text-slate-600"><SlidersHorizontal size={13} />Filters</button>
          </div>
          {showFilters && <div className="mt-3 max-h-[42vh] overflow-y-auto pr-1"><FilterPanel /></div>}
          {!params.treatment_id && <p className="mt-2 text-xs text-slate-500">Pick a treatment in Filters to see costs and treatment-based AI scores.</p>}
        </div>
        <div ref={listRef} className="min-h-0 flex-1 space-y-3 overflow-y-auto p-3">
          <ErrorBox>{geoMsg}</ErrorBox>
          <ErrorBox>{error}</ErrorBox>
          {loading && !data && <Spinner label="Finding hospitals…" />}
          {empty && (
            <div className="rounded-xl border border-dashed border-slate-300 bg-white p-5 text-sm text-slate-600">
              <p>{data.message || "No hospitals found."}</p>
              <p className="mt-1 text-xs">The demo dataset covers Islamabad, Rawalpindi and nearby cities.</p>
              <div className="mt-3 flex flex-wrap gap-2">
                <button className="rounded-lg bg-teal-600 px-3 py-1.5 font-semibold text-white" onClick={() => update({ radius_km: 200 })}>Try 200 km</button>
                <button className="rounded-lg border px-3 py-1.5 font-semibold" onClick={() => update({ lat: 33.6844, lng: 73.0479, locationLabel: "Islamabad (Centre)", locationSource: "preset" })}>Use Islamabad demo location</button>
              </div>
            </div>)}
          {hospitals.map((h) => <HospitalCard key={h.id} h={h} compact from={user} selected={selectedId === h.id} onSelect={() => fromList(h.id)} />)}
        </div>
      </aside>

      <section className={`${view === "map" ? "block" : "hidden"} relative min-h-0 flex-1 md:block`}>
        <HospitalMap user={user} radiusKm={params.radius_km} hospitals={hospitals} selectedId={selectedId} onSelect={fromMap} onDetails={(id) => nav(`/hospitals/${id}`)} />
        {loading && <div className="absolute left-1/2 top-3 z-[500] -translate-x-1/2 rounded-full bg-white px-4 py-1.5 text-xs font-semibold text-slate-600 shadow-soft">Updating hospitals…</div>}
      </section>
    </div>
  );
}
