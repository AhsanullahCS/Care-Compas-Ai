import { useEffect, useState } from "react";
import { Link } from "react-router-dom";
import { Banknote, Bot, Calculator, Map as MapIcon, Search, ShieldCheck, Stethoscope } from "lucide-react";
import { get } from "../services/api";
import { EmergencyNotice } from "../components/ui";

const steps = [
  ["Say what you need", "Enter a treatment, a specialist or the wording from your referral letter."],
  ["We check who can treat you", "Only hospitals that offer the treatment are considered — never just the cheapest or nearest."],
  ["Compare cost and support", "See estimated cost ranges, Sehat Card / insurance / aid listings and distance side by side."],
  ["Choose and go", "Call, get directions or save the hospital. Confirm details with the hospital first."],
];
const features = [
  [Stethoscope, "Treatment-first matching", "Treatment compatibility is mandatory, so a low price never outranks a hospital that can actually treat you."],
  [Banknote, "Affordability-aware ranking", "Budget, estimated cost and financial-assistance options are part of every score."],
  [Bot, "Referral assistant", "Paste a referral note; we pull out the specialist, treatment and department — no diagnosis."],
  [MapIcon, "Live interactive map", "Hospitals around you on OpenStreetMap, synced with a ranked list."],
  [Calculator, "Savings calculator", "See the estimated difference between hospitals, with honest disclaimers."],
  [ShieldCheck, "Verified vs demo labels", "Every price, scheme and location is labelled so nothing unverified looks official."],
];

export default function Landing() {
  const [stats, setStats] = useState(null);
  useEffect(() => { get("/stats").then(setStats).catch(() => {}); }, []);
  return (
    <>
      <section className="bg-gradient-to-br from-navy via-navy to-teal-700 text-white">
        <div className="mx-auto grid max-w-7xl items-center gap-10 px-4 py-16 md:grid-cols-2 md:py-24">
          <div>
            <h1 className="text-4xl font-extrabold leading-tight md:text-5xl">Find the Right Hospital. Get the Right Treatment. Save More.</h1>
            <p className="mt-5 max-w-xl text-lg text-blue-100">SehatRoute AI matches patients in Pakistan with hospitals that offer the treatment they need — ranked by distance, estimated cost, government support, Sehat Card and insurance acceptance.</p>
            <div className="mt-8 flex flex-wrap gap-3">
              <Link to="/dashboard" className="rounded-xl bg-white px-6 py-3 font-bold text-navy shadow-soft hover:bg-blue-50"><Search className="mr-2 inline" size={18} />Find Healthcare</Link>
              <a href="#how" className="rounded-xl border border-white/50 px-6 py-3 font-bold hover:bg-white/10">How It Works</a>
            </div>
          </div>
          <div className="rounded-3xl bg-white/10 p-6 backdrop-blur">
            <p className="text-sm font-semibold text-blue-100">What a patient sees</p>
            <div className="mt-3 space-y-3 rounded-2xl bg-white p-4 text-slate-800 shadow-soft">
              <div className="flex items-center justify-between"><b className="text-navy">Angioplasty · within 50 km</b><span className="rounded-lg bg-green-600 px-2 py-0.5 text-sm font-bold text-white">92/100</span></div>
              <p className="text-sm text-slate-600">Offers the treatment, cardiologist listed, 12 km away, comparatively low estimated cost, lists Sehat Card Plus.</p>
              <div className="flex gap-2 text-xs"><span className="rounded-full bg-green-100 px-2 py-0.5 font-semibold text-green-800">Government</span><span className="rounded-full bg-amber-100 px-2 py-0.5 font-semibold text-amber-800">Demo data</span></div>
            </div>
            <p className="mt-3 text-xs text-blue-100">Illustrative example.</p>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-10">
        <h2 className="sr-only">Platform data</h2>
        <div className="grid grid-cols-2 gap-4 md:grid-cols-4">
          {[["Hospitals in dataset", stats?.hospitals], ["Treatments covered", stats?.treatments], ["Assistance programs", stats?.programs], ["Verified hospitals", stats?.verified_hospitals]].map(([l, v]) => (
            <div key={l} className="rounded-2xl border border-slate-200 p-5 text-center shadow-soft"><p className="text-3xl font-extrabold text-navy">{v ?? "–"}</p><p className="text-sm text-slate-500">{l}</p></div>))}
        </div>
        <p className="mt-2 text-center text-xs text-slate-400">Live counts from this platform's database. The MVP ships with synthetic demo data for Islamabad, Rawalpindi and nearby areas.</p>
      </section>

      <section id="how" className="bg-slate-50 py-14">
        <div className="mx-auto max-w-7xl px-4">
          <h2 className="text-3xl font-extrabold text-navy">How it works</h2>
          <ol className="mt-8 grid gap-4 md:grid-cols-4">{steps.map(([t, d], i) => (
            <li key={t} className="rounded-2xl bg-white p-5 shadow-soft"><span className="flex h-8 w-8 items-center justify-center rounded-full bg-teal-600 font-bold text-white">{i + 1}</span><h3 className="mt-3 font-bold text-navy">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></li>))}</ol>
        </div>
      </section>

      <section className="mx-auto max-w-7xl px-4 py-14">
        <h2 className="text-3xl font-extrabold text-navy">Built to reduce wasted trips and costs</h2>
        <div className="mt-8 grid gap-4 md:grid-cols-3">{features.map(([Icon, t, d]) => (
          <div key={t} className="rounded-2xl border border-slate-200 p-5 shadow-soft"><Icon className="text-teal-600" /><h3 className="mt-3 font-bold text-navy">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></div>))}</div>
      </section>

      <section className="bg-green-50 py-14">
        <div className="mx-auto grid max-w-7xl items-center gap-6 px-4 md:grid-cols-2">
          <div><h2 className="text-3xl font-extrabold text-green-900">Government healthcare support, made visible</h2>
            <p className="mt-3 text-green-900/80">Choose your Sehat Card, insurance or aid program and we prioritise hospitals that list it — and clearly mark when that acceptance has not been verified.</p>
            <Link to="/financial-assistance" className="mt-5 inline-block rounded-xl bg-green-700 px-5 py-2.5 font-bold text-white hover:bg-green-800">Explore financial assistance</Link></div>
          <EmergencyNotice />
        </div>
      </section>
    </>
  );
}
