import { useEffect, useMemo, useState } from "react";
import { Link, useNavigate, useParams } from "react-router-dom";
import { Bar, BarChart, Cell, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { Flag, Heart, Navigation, Phone } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { useSearch } from "../context/SearchContext";
import { errMsg, get, post } from "../services/api";
import HospitalMap from "../components/HospitalMap";
import { DataBadge, EmergencyNotice, ErrorBox, Spinner, TypeBadge } from "../components/ui";
import { directionsUrl, pkr, priceRange, PROGRAM_TYPE_LABEL } from "../utils/format";

const STATUS = { accepted: "text-green-700", not_accepted: "text-slate-400", unknown: "text-amber-700" };

export default function HospitalDetail() {
  const { id } = useParams();
  const nav = useNavigate();
  const { user, savedIds, toggleSave } = useAuth();
  const { params } = useSearch();
  const [h, setH] = useState(null);
  const [err, setErr] = useState("");
  const [tid, setTid] = useState("");
  const [cmp, setCmp] = useState(null);
  const [report, setReport] = useState({ open: false, text: "", msg: "" });

  useEffect(() => { setH(null); get(`/hospitals/${id}`).then((d) => { setH(d); setTid(String(params.treatment_id || d.treatments.find((t) => t.price)?.id || "")); }).catch((e) => setErr(errMsg(e))); /* eslint-disable-next-line */ }, [id]);
  useEffect(() => { if (tid) get(`/treatments/${tid}/prices`).then(setCmp).catch(() => setCmp(null)); else setCmp(null); }, [tid]);

  const mapHospital = useMemo(() => h && [{ ...h, distance_km: 0, score: 0, price: null, matched_treatments: [], programs: h.programs }], [h]);
  if (err) return <div className="mx-auto max-w-3xl p-8"><ErrorBox>{err}</ErrorBox><Link className="text-teal-700" to="/dashboard">Back to search</Link></div>;
  if (!h) return <Spinner />;

  const from = { lat: params.lat, lng: params.lng };
  const grouped = h.treatments.reduce((a, t) => ((a[t.category] ||= []).push(t), a), {});
  const lowest = cmp?.prices?.[0];
  const submitReport = async (e) => {
    e.preventDefault();
    try { await post("/corrections", { hospital_id: h.id, message: report.text }); setReport({ open: false, text: "", msg: "Thank you — an administrator will review your correction." }); }
    catch (x) { setReport({ ...report, msg: errMsg(x) }); }
  };

  return (
    <div className="mx-auto max-w-7xl space-y-5 px-4 py-6">
      <button onClick={() => nav(-1)} className="text-sm font-semibold text-teal-700">← Back</button>
      <header className="rounded-2xl bg-gradient-to-r from-navy to-teal-700 p-6 text-white">
        <div className="flex flex-wrap items-start justify-between gap-3">
          <div><h1 className="text-2xl font-extrabold">{h.name}</h1><p className="mt-1 text-blue-100">{h.address}</p>
            <div className="mt-3 flex flex-wrap gap-2"><TypeBadge type={h.hospital_type} /><DataBadge h={h} />{h.emergency_available && <span className="rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-semibold text-red-800">Emergency department listed</span>}</div></div>
          <div className="flex flex-wrap gap-2">
            <a href={directionsUrl(h, from)} target="_blank" rel="noreferrer" className="inline-flex items-center gap-1 rounded-xl bg-white px-4 py-2 text-sm font-bold text-navy"><Navigation size={15} />Get Directions</a>
            {h.contact && <a href={`tel:${h.contact.replace(/[^+\d]/g, "")}`} className="inline-flex items-center gap-1 rounded-xl border border-white/60 px-4 py-2 text-sm font-bold"><Phone size={15} />{h.contact}</a>}
            <button onClick={() => (user ? toggleSave(h.id) : nav("/login"))} className="inline-flex items-center gap-1 rounded-xl border border-white/60 px-4 py-2 text-sm font-bold"><Heart size={15} fill={savedIds.has(h.id) ? "currentColor" : "none"} />{savedIds.has(h.id) ? "Saved" : "Save"}</button>
          </div>
        </div>
      </header>
      {h.notice && <ErrorBox>{h.notice} Location is {h.location_verified ? "verified" : "an approximate demo position"}; hours are {h.operating_hours ? "unverified" : "not listed"}.</ErrorBox>}

      <div className="grid gap-5 lg:grid-cols-3">
        <div className="space-y-5 lg:col-span-2">
          <section className="rounded-2xl border border-slate-200 p-5 shadow-soft">
            <h2 className="mb-3 font-bold text-navy">Departments, treatments & estimated prices</h2>
            {Object.entries(grouped).map(([cat, ts]) => (
              <div key={cat} className="mb-4"><h3 className="text-sm font-bold text-teal-700">{cat}</h3>
                <table className="mt-1 w-full text-sm"><tbody>{ts.map((t) => (
                  <tr key={t.id} className="border-b border-slate-100"><td className="py-1.5">{t.name}{t.status === "limited" && <span className="ml-1 text-xs text-amber-700">(limited capacity)</span>}</td>
                    <td className="py-1.5 text-right font-semibold text-green-700">{priceRange(t.price)}<span className="block text-[10px] font-normal text-slate-400">{t.price ? (t.price.verified ? "verified" : "demo estimate") : "price not listed"}</span></td></tr>))}</tbody></table></div>))}
          </section>

          <section className="rounded-2xl border border-slate-200 p-5 shadow-soft">
            <div className="mb-3 flex flex-wrap items-center justify-between gap-2"><h2 className="font-bold text-navy">Treatment cost comparison</h2>
              <select aria-label="Treatment to compare" className="rounded-lg border border-slate-200 px-2 py-1.5 text-sm" value={tid} onChange={(e) => setTid(e.target.value)}>
                <option value="">Choose treatment…</option>{h.treatments.map((t) => <option key={t.id} value={t.id}>{t.name}</option>)}</select></div>
            {cmp ? (<>
              <div className="h-64"><ResponsiveContainer><BarChart data={cmp.prices.map((p) => ({ name: p.hospital_name.replace(" (Demo)", ""), mid: p.mid, me: p.hospital_id === h.id }))} layout="vertical" margin={{ left: 10, right: 20 }}>
                <XAxis type="number" tickFormatter={(v) => `${Math.round(v / 1000)}k`} /><YAxis type="category" dataKey="name" width={150} tick={{ fontSize: 11 }} />
                <Tooltip formatter={(v) => pkr(v)} /><Bar dataKey="mid" radius={[0, 6, 6, 0]}>{cmp.prices.map((p) => <Cell key={p.hospital_id} fill={p.hospital_id === h.id ? "#0B3A6F" : "#14B8A6"} />)}</Bar></BarChart></ResponsiveContainer></div>
              <div className="max-h-56 overflow-auto"><table className="mt-2 w-full text-sm"><thead><tr className="text-left text-xs text-slate-500"><th>Hospital</th><th className="text-right">Estimated cost</th></tr></thead><tbody>{cmp.prices.map((p) => (
                <tr key={p.hospital_id} className={`border-t border-slate-100 ${p.hospital_id === h.id ? "bg-navy-light font-semibold" : ""}`}><td className="py-1.5"><Link className="hover:underline" to={`/hospitals/${p.hospital_id}`}>{p.hospital_name}</Link></td><td className="text-right">{pkr(p.min)} – {pkr(p.max)}</td></tr>))}</tbody></table></div>
              {lowest && <p className="mt-2 text-xs text-slate-500">Lowest listed: <b>{lowest.hospital_name}</b>. {cmp.disclaimer} Savings are not guaranteed.</p>}
            </>) : <p className="text-sm text-slate-500">Choose a treatment to compare estimated costs across hospitals.</p>}
          </section>
        </div>

        <div className="space-y-5">
          <section className="h-72 overflow-hidden rounded-2xl border border-slate-200 shadow-soft">
            <HospitalMap single user={from} radiusKm={3} hospitals={mapHospital} selectedId={h.id} onSelect={() => {}} onDetails={() => {}} />
          </section>
          <section className="rounded-2xl border border-slate-200 p-5 shadow-soft"><h2 className="mb-2 font-bold text-navy">Specialists</h2>
            {h.doctors.length ? <ul className="space-y-1 text-sm">{h.doctors.map((d) => <li key={d.id}><b>{d.name}</b> — {d.specialization} <span className="text-xs text-slate-400">({d.availability}, {h.verification_status === "verified" ? "verified" : "demo listing"})</span></li>)}</ul> : <p className="text-sm text-slate-500">No specialists listed.</p>}</section>
          <section className="rounded-2xl border border-slate-200 p-5 shadow-soft"><h2 className="mb-2 font-bold text-navy">Government schemes & insurance</h2>
            <ul className="space-y-1.5 text-sm">{h.programs.map((p) => <li key={p.program_id} className="flex justify-between gap-2"><span>{p.name} <span className="text-xs text-slate-400">({PROGRAM_TYPE_LABEL[p.type]})</span></span>
              <span className={`text-right text-xs font-semibold ${STATUS[p.status]}`}>{p.status === "accepted" ? "Listed as accepted" : p.status === "unknown" ? "Unknown" : "Not accepted"}{p.status !== "not_accepted" && <span className="block font-normal text-slate-400">{p.verified ? `verified ${p.verification_date?.slice(0, 10)}` : "unverified"}</span>}</span></li>)}</ul>
            <p className="mt-2 text-xs text-slate-500">Always confirm acceptance with the hospital before visiting.</p></section>
          <section className="rounded-2xl border border-slate-200 p-5 text-sm shadow-soft"><h2 className="mb-2 font-bold text-navy">Facilities & hours</h2>
            <p>{h.facilities.join(", ") || "—"}</p><p className="mt-2 text-slate-600">Hours: {h.operating_hours || "not listed"}</p>{h.website && <a className="text-teal-700" href={h.website}>Website</a>}</section>
          <button onClick={() => (user ? setReport({ ...report, open: !report.open }) : nav("/login"))} className="inline-flex items-center gap-1 text-sm font-semibold text-slate-500 hover:text-navy"><Flag size={14} />Report incorrect information</button>
          {report.open && <form onSubmit={submitReport} className="space-y-2"><textarea required minLength={5} className="w-full rounded-xl border border-slate-200 p-2 text-sm" rows={3} placeholder="What should be corrected?" value={report.text} onChange={(e) => setReport({ ...report, text: e.target.value })} /><button className="rounded-lg bg-navy px-3 py-1.5 text-sm font-bold text-white">Send correction</button></form>}
          {report.msg && <p className="text-xs text-teal-700">{report.msg}</p>}
        </div>
      </div>
      <EmergencyNotice />
    </div>
  );
}
