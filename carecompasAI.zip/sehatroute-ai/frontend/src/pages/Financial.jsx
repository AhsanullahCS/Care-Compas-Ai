import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Banknote, Building, HandHeart, HeartHandshake, Landmark, ShieldPlus } from "lucide-react";
import { get } from "../services/api";
import { useSearch } from "../context/SearchContext";
import { PROGRAM_TYPE_LABEL } from "../utils/format";

const ICONS = { government_card: ShieldPlus, insurance: Landmark, zakat: HandHeart, welfare: HeartHandshake, aid: Banknote };
const GUIDE = [
  [Building, "Government hospitals", "Public hospitals generally charge far less than private ones. Ask the registration desk what is free or subsidised for your treatment."],
  [HeartHandshake, "Hospital welfare departments", "Many hospitals assess patients for discounts or free care. Ask for the welfare or social-work office before treatment starts."],
  [HandHeart, "Zakat-based assistance", "Zakat committees and charities can fund treatment for eligible patients. Eligibility rules and paperwork differ by district."],
];

export default function Financial() {
  const [programs, setPrograms] = useState([]);
  const { params, update } = useSearch();
  const nav = useNavigate();
  useEffect(() => { get("/programs").then(setPrograms).catch(() => {}); }, []);
  const toggle = (id) => update({ program_ids: params.program_ids.includes(id) ? params.program_ids.filter((x) => x !== id) : [...params.program_ids, id] });
  return (
    <div className="mx-auto max-w-5xl space-y-8 px-4 py-8">
      <div><h1 className="text-2xl font-extrabold text-navy">Healthcare financial assistance</h1>
        <p className="mt-1 text-slate-600">Select the card, insurance or aid you can use. We'll prioritise hospitals that list it. Acceptance shown is <b>demo data</b> unless a hospital is marked verified — we never claim a hospital accepts a scheme without verification.</p></div>
      <section>
        <h2 className="mb-3 font-bold text-navy">Which do you have?</h2>
        <div className="grid gap-3 sm:grid-cols-2">{programs.map((p) => { const I = ICONS[p.program_type] || ShieldPlus; const on = params.program_ids.includes(p.id); return (
          <button key={p.id} onClick={() => toggle(p.id)} aria-pressed={on} className={`flex gap-3 rounded-2xl border p-4 text-left shadow-soft transition ${on ? "border-green-600 bg-green-50 ring-2 ring-green-500" : "border-slate-200 bg-white hover:border-green-400"}`}>
            <span className="flex h-10 w-10 shrink-0 items-center justify-center rounded-xl bg-green-100 text-green-700"><I size={20} /></span>
            <span><b className="block text-navy">{p.program_name}</b><span className="text-xs font-semibold text-teal-700">{PROGRAM_TYPE_LABEL[p.program_type]}</span><span className="mt-1 block text-sm text-slate-600">{p.description}</span></span></button>); })}</div>
        <button onClick={() => nav("/dashboard")} className="mt-4 rounded-xl bg-green-700 px-5 py-2.5 font-bold text-white hover:bg-green-800">{params.program_ids.length ? `Find hospitals supporting my ${params.program_ids.length} selection${params.program_ids.length > 1 ? "s" : ""}` : "Continue to hospital search"}</button>
      </section>
      <section><h2 className="mb-3 font-bold text-navy">Other ways to reduce cost</h2>
        <div className="grid gap-3 md:grid-cols-3">{GUIDE.map(([I, t, d]) => <div key={t} className="rounded-2xl border border-slate-200 p-4 shadow-soft"><I className="text-teal-600" /><h3 className="mt-2 font-bold text-navy">{t}</h3><p className="mt-1 text-sm text-slate-600">{d}</p></div>)}</div></section>
      <p className="rounded-xl bg-slate-50 p-3 text-xs text-slate-500">General information only; coverage, eligibility and amounts change. Confirm with the scheme's official channel and the hospital.</p>
    </div>
  );
}
