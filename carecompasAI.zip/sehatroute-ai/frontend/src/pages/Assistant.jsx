import { useEffect, useRef, useState } from "react";
import { Link } from "react-router-dom";
import { Bot, Send } from "lucide-react";
import { useSearch } from "../context/SearchContext";
import { errMsg, post } from "../services/api";
import { EmergencyNotice } from "../components/ui";

const SUGGEST = ["I need treatment for a heart condition, but I cannot afford expensive private hospitals", "Which hospitals offer dialysis near me?", "How does Sehat Card help?", "Compare costs for knee replacement"];

export default function Assistant() {
  const { params } = useSearch();
  const [msgs, setMsgs] = useState([{ role: "bot", text: "Salaam! I'm Sehat Assistant. Tell me the treatment or specialist you need and I'll find eligible hospitals. I can't diagnose conditions or prescribe medicine.", hospitals: [] }]);
  const [text, setText] = useState(""); const [busy, setBusy] = useState(false);
  const end = useRef(null);
  useEffect(() => { end.current?.scrollIntoView({ behavior: "smooth" }); }, [msgs]);

  const send = async (t) => {
    const m = (t ?? text).trim(); if (!m || busy) return;
    setText(""); setMsgs((x) => [...x, { role: "user", text: m }]); setBusy(true);
    try {
      const body = { message: m, radius_km: Number(params.radius_km) };
      if (params.locationSource === "gps") { body.lat = params.lat; body.lng = params.lng; }
      const r = await post("/assistant/chat", body);
      setMsgs((x) => [...x, { role: "bot", text: r.reply, hospitals: r.hospitals, emergency: r.emergency }]);
    } catch (e) { setMsgs((x) => [...x, { role: "bot", text: errMsg(e), hospitals: [] }]); } finally { setBusy(false); }
  };

  return (
    <div className="mx-auto flex h-[calc(100vh-4rem)] max-w-3xl flex-col px-4 py-4">
      <div className="mb-3 flex items-center gap-2"><span className="flex h-10 w-10 items-center justify-center rounded-xl bg-teal-600 text-white"><Bot /></span><div><h1 className="font-extrabold text-navy">Sehat Assistant</h1><p className="text-xs text-slate-500">Finds hospitals, explains schemes. No diagnosis, no prescriptions.</p></div></div>
      <EmergencyNotice className="mb-3" />
      <div className="flex-1 space-y-3 overflow-y-auto rounded-2xl border border-slate-200 bg-slate-50 p-4" aria-live="polite">
        {msgs.map((m, i) => (
          <div key={i} className={`flex ${m.role === "user" ? "justify-end" : ""}`}>
            <div className={`max-w-[85%] whitespace-pre-line rounded-2xl px-4 py-2.5 text-sm ${m.role === "user" ? "bg-navy text-white" : m.emergency ? "border border-red-300 bg-red-50 font-semibold text-red-800" : "bg-white shadow-soft"}`}>
              {m.text}
              {m.hospitals?.length > 0 && <div className="mt-2 flex flex-wrap gap-1.5">{m.hospitals.map((h) => <Link key={h.id} to={`/hospitals/${h.id}`} className="rounded-full bg-teal-50 px-2.5 py-1 text-xs font-semibold text-teal-800 hover:bg-teal-100">{h.name}</Link>)}</div>}
            </div></div>))}
        {busy && <p className="text-xs text-slate-400">Sehat Assistant is typing…</p>}
        <div ref={end} />
      </div>
      <div className="mt-2 flex flex-wrap gap-1.5">{SUGGEST.map((s) => <button key={s} onClick={() => send(s)} className="rounded-full border border-slate-200 px-3 py-1 text-xs text-slate-600 hover:border-teal-400">{s}</button>)}</div>
      <form onSubmit={(e) => { e.preventDefault(); send(); }} className="mt-2 flex gap-2">
        <input aria-label="Message" className="flex-1 rounded-xl border border-slate-200 px-3 py-2.5 text-sm focus:border-teal-500" placeholder="e.g. I need a cardiologist for angioplasty" value={text} onChange={(e) => setText(e.target.value)} maxLength={1000} />
        <button disabled={busy} className="rounded-xl bg-teal-600 px-4 text-white hover:bg-teal-700 disabled:opacity-60" aria-label="Send"><Send size={18} /></button></form>
      <p className="mt-1 text-center text-[11px] text-slate-400">{params.locationSource === "gps" ? "Using your shared location." : "No location shared — searches default to central Islamabad. Open the Map to share your location."}</p>
    </div>
  );
}
