import { useState } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import { useAuth } from "../context/AuthContext";
import { errMsg } from "../services/api";
import { ErrorBox } from "../components/ui";

function Shell({ title, children, foot }) {
  return (
    <div className="mx-auto max-w-md px-4 py-14">
      <div className="rounded-2xl border border-slate-200 p-6 shadow-soft"><h1 className="mb-4 text-2xl font-extrabold text-navy">{title}</h1>{children}</div>
      <p className="mt-4 text-center text-sm text-slate-500">{foot}</p>
    </div>
  );
}
const inp = "w-full rounded-xl border border-slate-200 px-3 py-2 text-sm focus:border-teal-500";

function useAuthForm(action) {
  const [err, setErr] = useState(""); const [busy, setBusy] = useState(false);
  const nav = useNavigate(); const loc = useLocation();
  const submit = async (e, ...args) => {
    e.preventDefault(); setErr(""); setBusy(true);
    try { await action(...args); nav(loc.state?.from || "/dashboard"); } catch (x) { setErr(errMsg(x)); } finally { setBusy(false); }
  };
  return { err, busy, submit };
}

export function Login() {
  const { login } = useAuth();
  const [f, setF] = useState({ email: "", password: "" });
  const { err, busy, submit } = useAuthForm(login);
  return (
    <Shell title="Log in" foot={<>New here? <Link className="font-semibold text-teal-700" to="/register">Create an account</Link></>}>
      <form onSubmit={(e) => submit(e, f.email, f.password)} className="space-y-3">
        <ErrorBox>{err}</ErrorBox>
        <div><label className="mb-1 block text-xs font-semibold text-slate-600" htmlFor="em">Email</label><input id="em" type="email" required className={inp} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="mb-1 block text-xs font-semibold text-slate-600" htmlFor="pw">Password</label><input id="pw" type="password" required className={inp} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
        <button disabled={busy} className="w-full rounded-xl bg-navy py-2.5 font-bold text-white hover:bg-navy-dark disabled:opacity-60">{busy ? "Logging in…" : "Log in"}</button>
        <p className="rounded-lg bg-slate-50 p-2 text-xs text-slate-500">Demo accounts (seeded locally): patient@sehatroute.demo / Patient@12345 · admin@sehatroute.demo / Admin@12345</p>
      </form>
    </Shell>
  );
}

export function Register() {
  const { register } = useAuth();
  const [f, setF] = useState({ name: "", email: "", password: "" });
  const { err, busy, submit } = useAuthForm(register);
  return (
    <Shell title="Create your account" foot={<>Already registered? <Link className="font-semibold text-teal-700" to="/login">Log in</Link></>}>
      <form onSubmit={(e) => submit(e, f.name, f.email, f.password)} className="space-y-3">
        <ErrorBox>{err}</ErrorBox>
        <div><label className="mb-1 block text-xs font-semibold text-slate-600" htmlFor="nm">Name</label><input id="nm" required minLength={2} className={inp} value={f.name} onChange={(e) => setF({ ...f, name: e.target.value })} /></div>
        <div><label className="mb-1 block text-xs font-semibold text-slate-600" htmlFor="em2">Email</label><input id="em2" type="email" required className={inp} value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></div>
        <div><label className="mb-1 block text-xs font-semibold text-slate-600" htmlFor="pw2">Password (8+ characters)</label><input id="pw2" type="password" required minLength={8} className={inp} value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /></div>
        <button disabled={busy} className="w-full rounded-xl bg-teal-600 py-2.5 font-bold text-white hover:bg-teal-700 disabled:opacity-60">{busy ? "Creating…" : "Sign up"}</button>
        <p className="text-xs text-slate-500">We only store your name, email and the hospitals/searches you save. No medical records are collected.</p>
      </form>
    </Shell>
  );
}
