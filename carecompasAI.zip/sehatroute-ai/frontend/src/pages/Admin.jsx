import { useCallback, useEffect, useState } from "react";
import { Bar, BarChart, CartesianGrid, Line, LineChart, ResponsiveContainer, Tooltip, XAxis, YAxis } from "recharts";
import { del, errMsg, get, post, put } from "../services/api";
import { ErrorBox } from "../components/ui";
import { TYPE_LABEL } from "../utils/format";

const inp = "w-full rounded-lg border border-slate-200 px-2 py-1.5 text-sm";
const Btn = ({ children, ...p }) => <button {...p} className={`rounded-lg bg-navy px-3 py-1.5 text-sm font-semibold text-white hover:bg-navy-dark ${p.className || ""}`}>{children}</button>;
const Card = ({ title, children }) => <section className="rounded-2xl border border-slate-200 p-4 shadow-soft"><h2 className="mb-3 font-bold text-navy">{title}</h2>{children}</section>;
const TABS = ["Analytics", "Hospitals", "Treatments & prices", "Doctors", "Programs", "Corrections"];

export default function Admin() {
  const [tab, setTab] = useState(TABS[0]);
  const [msg, setMsg] = useState({ ok: "", err: "" });
  const [hospitals, setHospitals] = useState([]);
  const [treatments, setTreatments] = useState([]);
  const [programs, setPrograms] = useState([]);
  const loadAll = useCallback(() => {
    get("/hospitals", { page_size: 200 }).then((d) => setHospitals(d.items));
    get("/treatments").then(setTreatments); get("/programs").then(setPrograms);
  }, []);
  useEffect(() => { loadAll(); }, [loadAll]);
  const act = async (fn, ok = "Saved") => { setMsg({ ok: "", err: "" }); try { await fn(); setMsg({ ok, err: "" }); loadAll(); } catch (e) { setMsg({ ok: "", err: errMsg(e) }); } };
  const props = { hospitals, treatments, programs, act, reload: loadAll };

  return (
    <div className="mx-auto max-w-7xl space-y-4 px-4 py-6">
      <h1 className="text-2xl font-extrabold text-navy">Admin dashboard</h1>
      <div className="flex flex-wrap gap-2">{TABS.map((t) => <button key={t} onClick={() => setTab(t)} className={`rounded-lg px-3 py-1.5 text-sm font-semibold ${tab === t ? "bg-navy text-white" : "bg-slate-100 text-slate-600"}`}>{t}</button>)}</div>
      <ErrorBox>{msg.err}</ErrorBox>{msg.ok && <p className="rounded-lg bg-green-50 p-2 text-sm text-green-800">{msg.ok}</p>}
      {tab === "Analytics" && <Analytics />}
      {tab === "Hospitals" && <Hospitals {...props} />}
      {tab === "Treatments & prices" && <Prices {...props} />}
      {tab === "Doctors" && <Doctors {...props} />}
      {tab === "Programs" && <Programs {...props} />}
      {tab === "Corrections" && <Corrections act={act} />}
    </div>
  );
}

function Analytics() {
  const [a, setA] = useState(null);
  useEffect(() => { get("/admin/analytics").then(setA); }, []);
  if (!a) return <p className="text-sm text-slate-500">Loading…</p>;
  return (
    <div className="space-y-4">
      <div className="grid grid-cols-2 gap-3 md:grid-cols-4">{[["Users", a.users], ["Hospitals", a.hospitals], ["Searches", a.searches], ["Open corrections", a.open_corrections]].map(([l, v]) => <div key={l} className="rounded-2xl border border-slate-200 p-4 text-center shadow-soft"><p className="text-3xl font-extrabold text-navy">{v}</p><p className="text-xs text-slate-500">{l}</p></div>)}</div>
      <div className="grid gap-4 md:grid-cols-2">
        <Card title="Hospitals by type"><div className="h-52"><ResponsiveContainer><BarChart data={a.by_type.map((d) => ({ ...d, name: TYPE_LABEL[d.name] || d.name }))}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="name" tick={{ fontSize: 11 }} /><YAxis allowDecimals={false} /><Tooltip /><Bar dataKey="value" fill="#14B8A6" radius={[6, 6, 0, 0]} /></BarChart></ResponsiveContainer></div></Card>
        <Card title="Searches per day (14 days)"><div className="h-52">{a.searches_per_day.length ? <ResponsiveContainer><LineChart data={a.searches_per_day}><CartesianGrid strokeDasharray="3 3" /><XAxis dataKey="day" tick={{ fontSize: 10 }} /><YAxis allowDecimals={false} /><Tooltip /><Line dataKey="searches" stroke="#0B3A6F" strokeWidth={2} /></LineChart></ResponsiveContainer> : <p className="text-sm text-slate-500">No logged-in searches yet.</p>}</div></Card>
        <Card title="Verification status"><ul className="text-sm">{a.by_verification.map((v) => <li key={v.name} className="flex justify-between border-b border-slate-100 py-1"><span className="capitalize">{v.name}</span><b>{v.value}</b></li>)}</ul></Card>
        <Card title="Top searches">{a.top_searches.length ? <ul className="text-sm">{a.top_searches.map((v) => <li key={v.name} className="flex justify-between border-b border-slate-100 py-1"><span>{v.name}</span><b>{v.value}</b></li>)}</ul> : <p className="text-sm text-slate-500">No searches logged yet.</p>}</Card>
      </div>
    </div>
  );
}

function Hospitals({ hospitals, act }) {
  const blank = { name: "", hospital_type: "private", address: "", city: "Islamabad", latitude: "", longitude: "", contact: "", operating_hours: "", location_verified: false };
  const [f, setF] = useState(blank); const [q, setQ] = useState("");
  const set = (k) => (e) => setF({ ...f, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  return (
    <div className="grid gap-4 lg:grid-cols-3">
      <Card title="Add hospital"><form className="space-y-2" onSubmit={(e) => { e.preventDefault(); act(async () => { await post("/admin/hospitals", { ...f, latitude: Number(f.latitude), longitude: Number(f.longitude), contact: f.contact || null, operating_hours: f.operating_hours || null }); setF(blank); }, "Hospital added (unverified)"); }}>
        <input required className={inp} placeholder="Name" value={f.name} onChange={set("name")} />
        <select className={inp} value={f.hospital_type} onChange={set("hospital_type")}>{Object.entries(TYPE_LABEL).map(([k, v]) => <option key={k} value={k}>{v}</option>)}</select>
        <input required className={inp} placeholder="Address" value={f.address} onChange={set("address")} /><input required className={inp} placeholder="City" value={f.city} onChange={set("city")} />
        <div className="grid grid-cols-2 gap-2"><input required type="number" step="any" className={inp} placeholder="Latitude" value={f.latitude} onChange={set("latitude")} /><input required type="number" step="any" className={inp} placeholder="Longitude" value={f.longitude} onChange={set("longitude")} /></div>
        <input className={inp} placeholder="Contact" value={f.contact} onChange={set("contact")} /><input className={inp} placeholder="Operating hours" value={f.operating_hours} onChange={set("operating_hours")} />
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={f.location_verified} onChange={set("location_verified")} />Coordinates surveyed/verified</label><Btn>Add hospital</Btn></form></Card>
      <div className="lg:col-span-2"><Card title={`Hospitals (${hospitals.length})`}>
        <input className={`${inp} mb-2`} placeholder="Filter by name…" value={q} onChange={(e) => setQ(e.target.value)} />
        <div className="max-h-[560px] overflow-auto"><table className="w-full text-sm"><thead className="text-left text-xs text-slate-500"><tr><th>Name</th><th>Type</th><th>Status</th><th /></tr></thead><tbody>{hospitals.filter((h) => h.name.toLowerCase().includes(q.toLowerCase())).map((h) => (
          <tr key={h.id} className="border-t border-slate-100"><td className="py-1.5">{h.name}</td><td>{TYPE_LABEL[h.hospital_type]}</td><td className="capitalize">{h.verification_status}</td>
            <td className="space-x-1 text-right">{h.verification_status === "verified" ? <Btn className="!bg-slate-500" onClick={() => act(() => post(`/admin/hospitals/${h.id}/verify?verified=false`), "Verification removed")}>Unverify</Btn> : <Btn onClick={() => act(() => post(`/admin/hospitals/${h.id}/verify`), "Hospital marked verified")}>Verify</Btn>}
              <Btn className="!bg-red-600" onClick={() => window.confirm(`Delete ${h.name}?`) && act(() => del(`/admin/hospitals/${h.id}`), "Deleted")}>Delete</Btn></td></tr>))}</tbody></table></div></Card></div>
    </div>
  );
}

function Prices({ hospitals, treatments, act }) {
  const [p, setP] = useState({ hospital_id: "", treatment_id: "", minimum_price: "", maximum_price: "", verified: false, availability_status: "available" });
  const [t, setT] = useState({ treatment_name: "", medical_category: "", specialist: "", description: "" });
  const sel = (k) => (e) => setP({ ...p, [k]: e.target.type === "checkbox" ? e.target.checked : e.target.value });
  const ids = { hospital_id: Number(p.hospital_id), treatment_id: Number(p.treatment_id) };
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card title="Hospital treatment availability & price">
        <div className="space-y-2">
          <select className={inp} value={p.hospital_id} onChange={sel("hospital_id")}><option value="">Hospital…</option>{hospitals.map((h) => <option key={h.id} value={h.id}>{h.name}</option>)}</select>
          <select className={inp} value={p.treatment_id} onChange={sel("treatment_id")}><option value="">Treatment…</option>{treatments.map((x) => <option key={x.id} value={x.id}>{x.treatment_name}</option>)}</select>
          <div className="flex gap-2"><select className={inp} value={p.availability_status} onChange={sel("availability_status")}><option>available</option><option>limited</option><option>unavailable</option></select>
            <Btn disabled={!p.hospital_id || !p.treatment_id} onClick={() => act(() => put("/admin/hospital-treatments", { ...ids, availability_status: p.availability_status }), "Availability updated")}>Set</Btn></div>
          <div className="grid grid-cols-2 gap-2"><input type="number" min="0" className={inp} placeholder="Min price PKR" value={p.minimum_price} onChange={sel("minimum_price")} /><input type="number" min="0" className={inp} placeholder="Max price PKR" value={p.maximum_price} onChange={sel("maximum_price")} /></div>
          <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={p.verified} onChange={sel("verified")} />Confirmed by the hospital (sets last-verified date)</label>
          <Btn disabled={!p.hospital_id || !p.treatment_id || !p.minimum_price || !p.maximum_price} onClick={() => act(() => put("/admin/prices", { ...ids, minimum_price: Number(p.minimum_price), maximum_price: Number(p.maximum_price), verified: p.verified }), "Price saved")}>Save price</Btn></div></Card>
      <Card title="Add treatment"><form className="space-y-2" onSubmit={(e) => { e.preventDefault(); act(() => post("/admin/treatments", { ...t, specialist: t.specialist || null, description: t.description || null }).then(() => setT({ treatment_name: "", medical_category: "", specialist: "", description: "" })), "Treatment added"); }}>
        <input required className={inp} placeholder="Treatment name" value={t.treatment_name} onChange={(e) => setT({ ...t, treatment_name: e.target.value })} /><input required className={inp} placeholder="Category / department" value={t.medical_category} onChange={(e) => setT({ ...t, medical_category: e.target.value })} />
        <input className={inp} placeholder="Specialist (e.g. Cardiologist)" value={t.specialist} onChange={(e) => setT({ ...t, specialist: e.target.value })} /><input className={inp} placeholder="Description" value={t.description} onChange={(e) => setT({ ...t, description: e.target.value })} /><Btn>Add</Btn></form></Card>
    </div>
  );
}

function Doctors({ hospitals, act }) {
  const [hid, setHid] = useState(""); const [docs, setDocs] = useState([]); const [d, setD] = useState({ name: "", specialization: "", availability_status: "available" });
  const load = useCallback((id) => id ? get(`/admin/doctors/${id}`).then(setDocs) : setDocs([]), []);
  useEffect(() => { load(hid); }, [hid, load]);
  return (
    <Card title="Manage doctors"><select className={`${inp} mb-3 max-w-md`} value={hid} onChange={(e) => setHid(e.target.value)}><option value="">Choose hospital…</option>{hospitals.map((h) => <option key={h.id} value={h.id}>{h.name}</option>)}</select>
      {hid && <div className="grid gap-4 md:grid-cols-2"><ul className="space-y-1 text-sm">{docs.map((x) => <li key={x.id} className="flex items-center justify-between border-b border-slate-100 py-1"><span>{x.name} — {x.specialization} ({x.availability_status})</span><Btn className="!bg-red-600" onClick={() => act(() => del(`/admin/doctors/${x.id}`).then(() => load(hid)), "Doctor removed")}>Remove</Btn></li>)}{!docs.length && <li className="text-slate-500">No doctors listed.</li>}</ul>
        <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); act(() => post("/admin/doctors", { ...d, hospital_id: Number(hid) }).then(() => { setD({ name: "", specialization: "", availability_status: "available" }); return load(hid); }), "Doctor added"); }}>
          <input required className={inp} placeholder="Name" value={d.name} onChange={(e) => setD({ ...d, name: e.target.value })} /><input required className={inp} placeholder="Specialization (e.g. Cardiologist)" value={d.specialization} onChange={(e) => setD({ ...d, specialization: e.target.value })} />
          <select className={inp} value={d.availability_status} onChange={(e) => setD({ ...d, availability_status: e.target.value })}><option>available</option><option>limited</option><option>unavailable</option></select><Btn>Add doctor</Btn></form></div>}</Card>
  );
}

function Programs({ hospitals, programs, act }) {
  const [p, setP] = useState({ program_name: "", program_type: "welfare", description: "" });
  const [hp, setHp] = useState({ hospital_id: "", program_id: "", acceptance_status: "accepted", verified: false });
  return (
    <div className="grid gap-4 md:grid-cols-2">
      <Card title="Healthcare programs"><ul className="mb-3 text-sm">{programs.map((x) => <li key={x.id} className="border-b border-slate-100 py-1">{x.program_name} <span className="text-xs text-slate-400">({x.program_type})</span></li>)}</ul>
        <form className="space-y-2" onSubmit={(e) => { e.preventDefault(); act(() => post("/admin/programs", { ...p, description: p.description || null }).then(() => setP({ program_name: "", program_type: "welfare", description: "" })), "Program added"); }}>
          <input required className={inp} placeholder="Program name" value={p.program_name} onChange={(e) => setP({ ...p, program_name: e.target.value })} />
          <select className={inp} value={p.program_type} onChange={(e) => setP({ ...p, program_type: e.target.value })}>{["government_card", "insurance", "zakat", "welfare", "aid"].map((x) => <option key={x}>{x}</option>)}</select>
          <input className={inp} placeholder="Description" value={p.description} onChange={(e) => setP({ ...p, description: e.target.value })} /><Btn>Add program</Btn></form></Card>
      <Card title="Set hospital acceptance"><div className="space-y-2">
        <select className={inp} value={hp.hospital_id} onChange={(e) => setHp({ ...hp, hospital_id: e.target.value })}><option value="">Hospital…</option>{hospitals.map((h) => <option key={h.id} value={h.id}>{h.name}</option>)}</select>
        <select className={inp} value={hp.program_id} onChange={(e) => setHp({ ...hp, program_id: e.target.value })}><option value="">Program…</option>{programs.map((x) => <option key={x.id} value={x.id}>{x.program_name}</option>)}</select>
        <select className={inp} value={hp.acceptance_status} onChange={(e) => setHp({ ...hp, acceptance_status: e.target.value })}><option>accepted</option><option>not_accepted</option><option>unknown</option></select>
        <label className="flex items-center gap-2 text-xs"><input type="checkbox" checked={hp.verified} onChange={(e) => setHp({ ...hp, verified: e.target.checked })} />Verified with the hospital/scheme (sets verification date)</label>
        <Btn disabled={!hp.hospital_id || !hp.program_id} onClick={() => act(() => put("/admin/hospital-programs", { ...hp, hospital_id: Number(hp.hospital_id), program_id: Number(hp.program_id) }), "Acceptance saved")}>Save</Btn></div></Card>
    </div>
  );
}

function Corrections({ act }) {
  const [rows, setRows] = useState([]);
  const load = useCallback(() => get("/admin/corrections").then(setRows), []);
  useEffect(() => { load(); }, [load]);
  return (
    <Card title="Submitted corrections">{rows.length === 0 ? <p className="text-sm text-slate-500">No corrections submitted.</p> : <ul className="space-y-2 text-sm">{rows.map((r) => (
      <li key={r.id} className="flex items-start justify-between gap-3 rounded-xl border border-slate-100 p-3"><div><b>{r.hospital_name}</b> <span className="text-xs text-slate-400">· {r.user_email || "anonymous"} · {r.created_at.slice(0, 10)}</span><p>{r.message}</p></div>
        {r.status === "open" ? <Btn onClick={() => act(() => post(`/admin/corrections/${r.id}/resolve`).then(load), "Marked resolved")}>Resolve</Btn> : <span className="text-xs font-semibold text-green-700">Resolved</span>}</li>))}</ul>}</Card>
  );
}
