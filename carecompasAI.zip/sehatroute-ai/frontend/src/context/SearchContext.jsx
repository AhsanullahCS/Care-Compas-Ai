import { createContext, useCallback, useContext, useEffect, useRef, useState } from "react";
import { errMsg, get, post } from "../services/api";

const Ctx = createContext(null);
export const useSearch = () => useContext(Ctx);

export const DEFAULTS = {
  lat: 33.6844, lng: 73.0479, locationLabel: "Islamabad (Centre)", locationSource: "preset", radius_km: 50,
  treatment_id: "", specialist: "", condition: "", query: "", hospital_types: [], program_ids: [], max_budget: "",
  financial_assistance: false, sort: "ai", weights: null,
};

export const toBody = (p) => ({
  lat: p.lat, lng: p.lng, radius_km: Number(p.radius_km), treatment_id: p.treatment_id ? Number(p.treatment_id) : null,
  specialist: p.specialist || null, condition: p.condition || null, query: p.query || null,
  hospital_types: p.hospital_types, program_ids: p.program_ids, max_budget: p.max_budget ? Number(p.max_budget) : null,
  financial_assistance: p.financial_assistance, sort: p.sort, weights: p.weights, location_label: p.locationLabel, page_size: 200,
});

export function SearchProvider({ children }) {
  const [params, setParams] = useState(DEFAULTS);
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState("");
  const [meta, setMeta] = useState(null);
  const [geoMsg, setGeoMsg] = useState("");
  const reqId = useRef(0);

  useEffect(() => { get("/search/filters").then(setMeta).catch((e) => setError(errMsg(e))); }, []);

  const update = useCallback((patch) => setParams((p) => ({ ...p, ...patch })), []);

  const run = useCallback(async (p) => {
    const id = ++reqId.current;
    setLoading(true); setError("");
    try {
      const d = await post("/search/hospitals", toBody(p));
      if (id === reqId.current) setData(d);
    } catch (e) { if (id === reqId.current) setError(errMsg(e)); }
    finally { if (id === reqId.current) setLoading(false); }
  }, []);

  const locate = useCallback(() => new Promise((resolve) => {
    if (!navigator.geolocation) { setGeoMsg("Your browser does not support geolocation. Choose an area instead."); return resolve(false); }
    setGeoMsg("Requesting your location…");
    navigator.geolocation.getCurrentPosition(
      (pos) => { update({ lat: pos.coords.latitude, lng: pos.coords.longitude, locationLabel: "My location", locationSource: "gps" }); setGeoMsg(""); resolve(true); },
      (err) => {
        setGeoMsg(err.code === 1 ? "Location permission denied — showing the selected area instead. Allow location in your browser to use your position."
          : "Could not determine your location — showing the selected area instead.");
        resolve(false);
      }, { enableHighAccuracy: true, timeout: 10000, maximumAge: 60000 });
  }), [update]);

  return <Ctx.Provider value={{ params, update, setParams, data, loading, error, meta, run, locate, geoMsg }}>{children}</Ctx.Provider>;
}
