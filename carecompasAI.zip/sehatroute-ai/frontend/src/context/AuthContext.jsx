import { createContext, useCallback, useContext, useEffect, useState } from "react";
import { del, get, post } from "../services/api";

const Ctx = createContext(null);
export const useAuth = () => useContext(Ctx);

export function AuthProvider({ children }) {
  const [user, setUser] = useState(null);
  const [ready, setReady] = useState(false);
  const [savedIds, setSavedIds] = useState(new Set());

  const loadSaved = useCallback(async () => {
    try { setSavedIds(new Set((await get("/saved-hospitals")).map((h) => h.id))); } catch { setSavedIds(new Set()); }
  }, []);

  useEffect(() => {
    if (!localStorage.getItem("sr_token")) { setReady(true); return; }
    get("/auth/me").then((u) => { setUser(u); return loadSaved(); })
      .catch(() => localStorage.removeItem("sr_token")).finally(() => setReady(true));
  }, [loadSaved]);

  const finish = async (data) => { localStorage.setItem("sr_token", data.access_token); setUser(data.user); await loadSaved(); return data.user; };
  const login = async (email, password) => finish(await post("/auth/login", { email, password }));
  const register = async (name, email, password) => finish(await post("/auth/register", { name, email, password }));
  const logout = () => { localStorage.removeItem("sr_token"); setUser(null); setSavedIds(new Set()); };
  const toggleSave = async (id) => {
    if (savedIds.has(id)) { await del(`/saved-hospitals/${id}`); setSavedIds((s) => { const n = new Set(s); n.delete(id); return n; }); }
    else { await post("/saved-hospitals", { hospital_id: id }); setSavedIds((s) => new Set(s).add(id)); }
  };
  return <Ctx.Provider value={{ user, ready, login, register, logout, savedIds, toggleSave, loadSaved }}>{children}</Ctx.Provider>;
}
