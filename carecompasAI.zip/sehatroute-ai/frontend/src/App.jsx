import { Navigate, Route, Routes } from "react-router-dom";
import Layout from "./layouts/Layout";
import { useAuth } from "./context/AuthContext";
import Landing from "./pages/Landing";
import { Login, Register } from "./pages/Auth";
import Dashboard from "./pages/Dashboard";
import MapExplorer from "./pages/MapExplorer";
import HospitalDetail from "./pages/HospitalDetail";
import Financial from "./pages/Financial";
import Assistant from "./pages/Assistant";
import Admin from "./pages/Admin";

function AdminOnly({ children }) {
  const { user, ready } = useAuth();
  if (!ready) return null;
  if (!user) return <Navigate to="/login" replace />;
  return user.is_admin ? children : <Navigate to="/dashboard" replace />;
}

export default function App() {
  return (
    <Routes>
      <Route element={<Layout />}>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login />} />
        <Route path="/register" element={<Register />} />
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/map" element={<MapExplorer />} />
        <Route path="/hospitals/:id" element={<HospitalDetail />} />
        <Route path="/financial-assistance" element={<Financial />} />
        <Route path="/assistant" element={<Assistant />} />
        <Route path="/admin" element={<AdminOnly><Admin /></AdminOnly>} />
        <Route path="*" element={<div className="p-16 text-center"><h1 className="text-2xl font-bold text-navy">Page not found</h1></div>} />
      </Route>
    </Routes>
  );
}
