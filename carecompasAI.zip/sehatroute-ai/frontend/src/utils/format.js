export const pkr = (n) => (n == null ? "—" : "PKR " + Math.round(n).toLocaleString("en-PK"));
export const priceRange = (p) => (p ? `${pkr(p.min)} – ${pkr(p.max)}` : "—");
export const TYPE_LABEL = { government: "Government", private: "Private", semi_government: "Semi-govt / Trust" };
export const TYPE_STYLE = {
  government: "bg-green-100 text-green-800",
  semi_government: "bg-teal-100 text-teal-800",
  private: "bg-blue-100 text-blue-800",
};
export const FACTOR_LABEL = {
  treatment: "Treatment match", specialist: "Specialist", distance: "Distance",
  affordability: "Affordability", government: "Govt. support", insurance: "Card / insurance",
};
export const directionsUrl = (h, from) =>
  `https://www.google.com/maps/dir/?api=1&destination=${h.latitude},${h.longitude}` + (from ? `&origin=${from.lat},${from.lng}` : "");
export const PROGRAM_TYPE_LABEL = { government_card: "Government card", insurance: "Insurance", zakat: "Zakat", welfare: "Hospital welfare", aid: "Financial aid" };
export const acceptedPrograms = (h) => (h.programs || []).filter((p) => p.status === "accepted");
