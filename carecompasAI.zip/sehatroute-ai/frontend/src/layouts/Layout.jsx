import { useState } from "react";
import { Link, NavLink, Outlet, useLocation, useNavigate } from "react-router-dom";
import { LogOut, Menu, X } from "lucide-react";
import { useAuth } from "../context/AuthContext";

export const Logo = ({ light }) => (
  <span className="flex items-center gap-2 text-lg font-extrabold tracking-tight">
    <svg width="30" height="30" viewBox="0 0 32 32" aria-hidden="true"><rect width="32" height="32" rx="8" fill={light ? "#fff" : "#0B3A6F"} /><path d="M16 6c-4.4 0-8 3.4-8 7.7C8 19.6 16 26 16 26s8-6.4 8-12.3C24 9.4 20.4 6 16 6z" fill="#14B8A6" /><path d="M16 10.5v6M13 13.5h6" stroke={light ? "#0B3A6F" : "#fff"} strokeWidth="2" strokeLinecap="round" /></svg>
    <span className={light ? "text-white" : "text-navy"}>SehatRoute <span className="text-teal-600">AI</span></span>
  </span>
);

export default function Layout() {
  const { user, logout } = useAuth();
  const [open, setOpen] = useState(false);
  const { pathname } = useLocation();
  const nav = useNavigate();
  const links = [["/dashboard", "Find Healthcare"], ["/map", "Hospital Map"], ["/financial-assistance", "Financial Aid"], ["/assistant", "Sehat Assistant"], ...(user?.is_admin ? [["/admin", "Admin"]] : [])];
  const cls = ({ isActive }) => `rounded-lg px-3 py-2 text-sm font-semibold ${isActive ? "bg-navy-light text-navy" : "text-slate-600 hover:text-navy"}`;
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-[1100] border-b border-slate-200 bg-white/95 backdrop-blur">
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-4">
          <Link to="/" aria-label="SehatRoute AI home"><Logo /></Link>
          <nav className="hidden items-center gap-1 md:flex">{links.map(([to, t]) => <NavLink key={to} to={to} className={cls}>{t}</NavLink>)}</nav>
          <div className="hidden items-center gap-2 md:flex">
            {user ? (<><span className="text-sm text-slate-600">Hi, {user.name.split(" ")[0]}</span>
              <button onClick={() => { logout(); nav("/"); }} className="inline-flex items-center gap-1 rounded-lg border border-slate-200 px-3 py-1.5 text-sm font-semibold hover:bg-slate-50"><LogOut size={14} />Log out</button></>)
              : (<><Link to="/login" className="rounded-lg px-3 py-1.5 text-sm font-semibold text-navy">Log in</Link><Link to="/register" className="rounded-lg bg-teal-600 px-3 py-1.5 text-sm font-bold text-white hover:bg-teal-700">Sign up</Link></>)}
          </div>
          <button className="md:hidden" onClick={() => setOpen(!open)} aria-label="Toggle menu">{open ? <X /> : <Menu />}</button>
        </div>
        {open && (
          <div className="space-y-1 border-t border-slate-100 bg-white px-4 py-3 md:hidden" onClick={() => setOpen(false)}>
            {links.map(([to, t]) => <NavLink key={to} to={to} className={cls}>{t}</NavLink>)}
            {user ? <button onClick={() => { logout(); nav("/"); }} className="px-3 py-2 text-sm font-semibold text-slate-600">Log out</button>
              : <div className="flex gap-2 pt-1"><Link to="/login" className="rounded-lg border px-3 py-1.5 text-sm font-semibold">Log in</Link><Link to="/register" className="rounded-lg bg-teal-600 px-3 py-1.5 text-sm font-bold text-white">Sign up</Link></div>}
          </div>
        )}
      </header>
      <main className="flex-1"><Outlet /></main>
      {!pathname.startsWith("/map") && (
        <footer className="bg-navy-dark text-slate-300">
          <div className="mx-auto grid max-w-7xl gap-6 px-4 py-10 md:grid-cols-3">
            <div><Logo light /><p className="mt-3 text-sm">Helping patients find suitable, affordable hospitals — fewer wasted trips, clearer costs.</p></div>
            <div className="text-sm"><b className="text-white">Explore</b><ul className="mt-2 space-y-1"><li><Link to="/dashboard">Find healthcare</Link></li><li><Link to="/map">Hospital map</Link></li><li><Link to="/financial-assistance">Financial assistance</Link></li></ul></div>
            <p className="text-xs leading-relaxed text-slate-400">SehatRoute AI is an information tool. It does not diagnose, prescribe or replace a doctor. In an emergency call Rescue 1122 / Edhi 115 or go to the nearest emergency department. Hospital data in this MVP is <b>synthetic demo data</b> unless a listing is marked verified.</p>
          </div>
        </footer>
      )}
    </div>
  );
}
