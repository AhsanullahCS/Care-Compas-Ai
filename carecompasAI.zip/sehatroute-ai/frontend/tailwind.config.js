/** @type {import('tailwindcss').Config} */
export default {
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: { navy: { DEFAULT: "#0B3A6F", dark: "#082B54", light: "#E8F0FA" } },
      fontFamily: { sans: ["Manrope", "ui-sans-serif", "system-ui", "sans-serif"] },
      boxShadow: { soft: "0 6px 24px -8px rgba(11,58,111,.18)" },
    },
  },
  plugins: [],
};
