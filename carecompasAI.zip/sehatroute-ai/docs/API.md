# SehatRoute AI — API summary
Interactive docs (Swagger): `http://localhost:8000/docs` · ReDoc: `/redoc`. All routes are under `/api`.

| Area | Endpoint | Auth |
|---|---|---|
| Auth | `POST /auth/register`, `POST /auth/login`, `GET /auth/me` | – / – / user |
| Hospitals | `GET /hospitals` (q, city, hospital_type, verification_status, page, page_size), `GET /hospitals/nearby`, `GET /hospitals/{id}`, `GET /hospitals/{id}/programs` | – |
| Search | `POST /search/hospitals`, `GET /search/filters`, `GET /search/history` | optional / – / user |
| AI | `POST /ai/recommend`, `POST /ai/explain`, `POST /ai/referral`, `POST /assistant/chat` | optional |
| Programs / prices | `GET /programs`, `GET /treatments`, `GET /treatments/{id}/prices` | – |
| Saved | `POST /saved-hospitals`, `GET /saved-hospitals`, `DELETE /saved-hospitals/{hospital_id}` | user |
| Corrections | `POST /corrections` | user |
| Admin | `/admin/...` hospitals, verify, treatments, prices, hospital-treatments, doctors, programs, hospital-programs, corrections, analytics | admin |

`POST /search/hospitals` body: `lat, lng, radius_km (1-200), treatment_id | specialist | condition | query, hospital_types[], program_ids[], max_budget, financial_assistance, sort (ai|distance|cost|government), weights{treatment,specialist,distance,affordability,government,insurance}, page, page_size (<=200)`.
Response: `query`, `total`, `results[]` (score, breakdown, explanation, flags, price, programs, coordinates…), `comparison` (best_match, nearest, lowest_cost, with_financial_support, savings, disclaimer).

Errors use `{"detail": "..."}` with 401 / 403 / 404 / 409 / 422 / 429 / 500.
Note: `DELETE /saved-hospitals/{hospital_id}` takes the **hospital id**.
