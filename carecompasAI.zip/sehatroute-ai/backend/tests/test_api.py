from tests.conftest import tid

ISB = {"lat": 33.6844, "lng": 73.0479}


def search(client, **kw):
    r = client.post("/api/search/hospitals", json={**ISB, "page_size": 200, **kw})
    assert r.status_code == 200, r.text
    return r.json()


# ---- auth -------------------------------------------------------------
def test_register_login_me(client):
    r = client.post("/api/auth/register", json={"name": "Test User", "email": "t@example.com", "password": "longpassword1"})
    assert r.status_code == 201
    assert client.post("/api/auth/register", json={"name": "Test User", "email": "T@example.com", "password": "longpassword1"}).status_code == 409
    assert client.post("/api/auth/login", json={"email": "t@example.com", "password": "wrong"}).status_code == 401
    token = client.post("/api/auth/login", json={"email": "t@example.com", "password": "longpassword1"}).json()["access_token"]
    me = client.get("/api/auth/me", headers={"Authorization": f"Bearer {token}"}).json()
    assert me["email"] == "t@example.com" and me["is_admin"] is False and "hashed_password" not in me


def test_validation_and_auth_errors(client):
    assert client.post("/api/auth/register", json={"name": "A", "email": "bad", "password": "x"}).status_code == 422
    assert client.get("/api/auth/me").status_code == 401
    assert client.post("/api/search/hospitals", json={"radius_km": 5000}).status_code == 422
    assert client.get("/api/hospitals/99999").status_code == 404


# ---- dataset ----------------------------------------------------------
def test_demo_dataset_is_labelled(client):
    data = client.get("/api/hospitals", params={"page_size": 200}).json()
    assert data["total"] == 30
    assert all(h["verification_status"] == "demo" and h["location_verified"] is False for h in data["items"])
    assert len({(h["latitude"], h["longitude"]) for h in data["items"]}) == 30  # fixed, distinct coordinates


# ---- search / radius / eligibility -----------------------------------
def test_radius_expands_results(client, filters):
    t = tid(filters, "Angiography")
    counts = [search(client, treatment_id=t, radius_km=r)["total"] for r in (10, 25, 50, 100, 200)]
    assert counts == sorted(counts) and counts[0] < counts[-1]
    for r in search(client, treatment_id=t, radius_km=25)["results"]:
        assert r["distance_km"] <= 25


def test_treatment_compatibility_is_mandatory(client, filters):
    t = tid(filters, "Hemodialysis")
    res = search(client, treatment_id=t, sort="cost")["results"]
    assert res
    for r in res:
        assert any(m["name"] == "Hemodialysis" for m in r["matched_treatments"])
    # an eye hospital must never be returned for dialysis, however cheap or near it is
    assert not any("Eye" in r["name"] for r in res)


def test_ai_ranking_scores_and_breakdown(client, filters):
    res = search(client, treatment_id=tid(filters, "Angioplasty (Stent)"), radius_km=100)["results"]
    scores = [r["score"] for r in res]
    assert scores == sorted(scores, reverse=True) and all(0 <= s <= 100 for s in scores)
    top = res[0]
    assert abs(sum(v["weight"] for v in top["breakdown"].values()) - 100) < 0.5
    assert top["explanation"].startswith("Recommended because")
    assert "demo" in top["explanation"].lower()


def test_custom_weights_change_ranking(client, filters):
    t = tid(filters, "Angiography")
    a = search(client, treatment_id=t, radius_km=100, weights={"distance": 1, "treatment": 0, "specialist": 0, "affordability": 0, "government": 0, "insurance": 0})["results"]
    assert a[0]["distance_km"] == min(r["distance_km"] for r in a)


def test_cost_comparison(client, filters):
    data = search(client, treatment_id=tid(filters, "Knee Replacement"), radius_km=100)
    cmp_ = data["comparison"]
    mids = [r["price"]["mid"] for r in data["results"] if r["price"]]
    assert cmp_["lowest_cost"]["price"]["mid"] == min(mids)
    assert cmp_["savings"]["potential_difference"] == max(mids) - min(mids)
    assert "guaranteed" in cmp_["disclaimer"].lower() or "estimates" in cmp_["disclaimer"].lower()
    cost_sorted = search(client, treatment_id=tid(filters, "Knee Replacement"), radius_km=100, sort="cost")["results"]
    prices = [r["price"]["mid"] for r in cost_sorted]
    assert prices == sorted(prices)


def test_program_and_type_filters(client, filters):
    sehat = next(p["id"] for p in filters["programs"] if p["name"] == "Sehat Card Plus")
    t = tid(filters, "Angiography")
    res = search(client, treatment_id=t, radius_km=100, program_ids=[sehat])["results"]
    assert res and all(any(p["program_id"] == sehat and p["status"] == "accepted" for p in r["programs"]) for r in res)
    gov = search(client, treatment_id=t, radius_km=100, hospital_types=["government"])["results"]
    assert all(r["hospital_type"] == "government" for r in gov)


def test_unverified_flags_never_claim_verified(client, filters):
    for r in search(client, treatment_id=tid(filters, "Angiography"))["results"]:
        assert "demo_data" in r["flags"] and "location_approximate" in r["flags"] and r["hours_verified"] is False


def test_referral_text_search_and_unrecognised(client):
    r = client.post("/api/ai/referral", json={"text": "Referred for angioplasty, cannot afford private hospital", **ISB, "radius_km": 50}).json()
    assert r["extraction"]["department"] == "Cardiology" and r["extraction"]["specialist"] == "Cardiologist"
    assert r["search"]["total"] > 0
    nothing = search(client, query="zzz qqq")
    assert nothing["results"] == [] and "diagnose" in nothing["message"]


def test_no_requirement_lists_nearby_hospitals(client):
    data = search(client, radius_km=10)
    assert data["total"] > 0 and data["comparison"].get("note")


# ---- assistant safety -------------------------------------------------
def test_assistant_emergency_and_no_diagnosis(client):
    e = client.post("/api/assistant/chat", json={"message": "I have severe chest pain right now"}).json()
    assert e["emergency"] is True and "emergency" in e["reply"].lower()
    d = client.post("/api/assistant/chat", json={"message": "Can you diagnose what disease I have?"}).json()
    assert "can't diagnose" in d["reply"]
    ok = client.post("/api/assistant/chat", json={"message": "I need a cardiologist but can't afford private hospitals", **ISB}).json()
    assert ok["hospitals"] and "demo" in ok["disclaimer"].lower()


def test_explain_endpoint(client, filters):
    first = search(client, treatment_id=tid(filters, "Angiography"))["results"][0]
    r = client.post("/api/ai/explain", json={**ISB, "treatment_id": tid(filters, "Angiography"), "hospital_id": first["id"]})
    assert r.status_code == 200 and r.json()["score"] == first["score"]


# ---- saved hospitals & history ---------------------------------------
def test_saved_hospitals_and_history(client, user_headers):
    assert client.post("/api/saved-hospitals", json={"hospital_id": 1}).status_code == 401
    assert client.post("/api/saved-hospitals", json={"hospital_id": 1}, headers=user_headers).status_code == 201
    assert client.post("/api/saved-hospitals", json={"hospital_id": 99999}, headers=user_headers).status_code == 404
    assert [h["id"] for h in client.get("/api/saved-hospitals", headers=user_headers).json()] == [1]
    assert client.delete("/api/saved-hospitals/1", headers=user_headers).status_code == 204
    assert client.get("/api/saved-hospitals", headers=user_headers).json() == []
    client.post("/api/search/hospitals", json=ISB, headers=user_headers)
    assert len(client.get("/api/search/history", headers=user_headers).json()) >= 1


# ---- admin ------------------------------------------------------------
def test_admin_protected_and_verification_flow(client, admin_headers, user_headers, filters):
    assert client.get("/api/admin/analytics").status_code == 401
    assert client.get("/api/admin/analytics", headers=user_headers).status_code == 403
    assert client.get("/api/admin/analytics", headers=admin_headers).json()["hospitals"] >= 30
    new = client.post("/api/admin/hospitals", headers=admin_headers, json={
        "name": "Verified Test Hospital", "hospital_type": "private", "address": "Test Rd", "city": "Islamabad",
        "latitude": 33.69, "longitude": 73.05}).json()["id"]
    t = tid(filters, "Angiography")
    assert client.put("/api/admin/hospital-treatments", headers=admin_headers, json={"hospital_id": new, "treatment_id": t}).status_code == 200
    assert client.put("/api/admin/prices", headers=admin_headers, json={"hospital_id": new, "treatment_id": t, "minimum_price": 100, "maximum_price": 200, "verified": True}).status_code == 200
    assert client.put("/api/admin/prices", headers=admin_headers, json={"hospital_id": new, "treatment_id": t, "minimum_price": 300, "maximum_price": 200}).status_code == 422
    assert client.post(f"/api/admin/hospitals/{new}/verify", headers=admin_headers).json()["verification_status"] == "verified"
    r = next(x for x in search(client, treatment_id=t, radius_km=10)["results"] if x["id"] == new)
    assert r["price"]["verified"] is True and "demo_data" not in r["flags"] and r["location_verified"] is True
    c = client.post("/api/corrections", headers=user_headers, json={"hospital_id": new, "message": "Phone number is wrong"})
    assert c.status_code == 201
    cid = client.get("/api/admin/corrections", headers=admin_headers).json()[0]["id"]
    assert client.post(f"/api/admin/corrections/{cid}/resolve", headers=admin_headers).json()["status"] == "resolved"
