-- SehatRoute AI schema (PostgreSQL syntax; SQLite also accepts it with SERIAL -> INTEGER PRIMARY KEY AUTOINCREMENT).
-- The app also creates these tables automatically on startup (SQLAlchemy create_all). Use this file to
-- provision PostgreSQL explicitly:  psql "$DATABASE_URL" -f backend/migrations/001_init.sql
CREATE TABLE users (id SERIAL PRIMARY KEY, name VARCHAR(120) NOT NULL, email VARCHAR(200) NOT NULL UNIQUE,
  hashed_password VARCHAR(300) NOT NULL, is_admin BOOLEAN NOT NULL DEFAULT FALSE, created_at TIMESTAMP NOT NULL DEFAULT NOW());
CREATE TABLE hospitals (id SERIAL PRIMARY KEY, name VARCHAR(200) NOT NULL, hospital_type VARCHAR(30) NOT NULL,
  address VARCHAR(300) NOT NULL, city VARCHAR(80) NOT NULL, latitude DOUBLE PRECISION NOT NULL, longitude DOUBLE PRECISION NOT NULL,
  contact VARCHAR(60), website VARCHAR(200), operating_hours VARCHAR(120), verification_status VARCHAR(20) NOT NULL DEFAULT 'unverified',
  location_verified BOOLEAN NOT NULL DEFAULT FALSE, facilities TEXT DEFAULT '[]', emergency_available BOOLEAN DEFAULT FALSE,
  data_source VARCHAR(60) DEFAULT 'demo', created_at TIMESTAMP DEFAULT NOW());
CREATE INDEX ix_hospitals_name ON hospitals(name);
CREATE INDEX ix_hospitals_type ON hospitals(hospital_type);
CREATE INDEX ix_hospitals_city ON hospitals(city);
CREATE INDEX ix_hospitals_verification ON hospitals(verification_status);
CREATE INDEX ix_hospitals_geo ON hospitals(latitude, longitude);
CREATE TABLE treatments (id SERIAL PRIMARY KEY, treatment_name VARCHAR(150) NOT NULL UNIQUE, description TEXT,
  medical_category VARCHAR(80) NOT NULL, specialist VARCHAR(80));
CREATE INDEX ix_treatments_category ON treatments(medical_category);
CREATE TABLE hospital_treatments (id SERIAL PRIMARY KEY, hospital_id INT NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  treatment_id INT NOT NULL REFERENCES treatments(id) ON DELETE CASCADE, availability_status VARCHAR(20) NOT NULL DEFAULT 'available',
  UNIQUE (hospital_id, treatment_id));
CREATE INDEX ix_ht_hospital ON hospital_treatments(hospital_id);
CREATE INDEX ix_ht_treatment ON hospital_treatments(treatment_id);
CREATE TABLE doctors (id SERIAL PRIMARY KEY, hospital_id INT NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  name VARCHAR(150) NOT NULL, specialization VARCHAR(80) NOT NULL, availability_status VARCHAR(20) DEFAULT 'available');
CREATE INDEX ix_doctors_hospital ON doctors(hospital_id);
CREATE INDEX ix_doctors_spec ON doctors(specialization);
CREATE TABLE treatment_prices (id SERIAL PRIMARY KEY, hospital_id INT NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  treatment_id INT NOT NULL REFERENCES treatments(id) ON DELETE CASCADE, minimum_price DOUBLE PRECISION NOT NULL,
  maximum_price DOUBLE PRECISION NOT NULL, last_verified TIMESTAMP, UNIQUE (hospital_id, treatment_id));
CREATE INDEX ix_tp_hospital ON treatment_prices(hospital_id);
CREATE INDEX ix_tp_treatment ON treatment_prices(treatment_id);
CREATE TABLE healthcare_programs (id SERIAL PRIMARY KEY, program_name VARCHAR(150) NOT NULL UNIQUE,
  program_type VARCHAR(30) NOT NULL, description TEXT);
CREATE TABLE hospital_programs (id SERIAL PRIMARY KEY, hospital_id INT NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE,
  program_id INT NOT NULL REFERENCES healthcare_programs(id) ON DELETE CASCADE, acceptance_status VARCHAR(20) NOT NULL DEFAULT 'unknown',
  verification_date TIMESTAMP, UNIQUE (hospital_id, program_id));
CREATE INDEX ix_hp_hospital ON hospital_programs(hospital_id);
CREATE INDEX ix_hp_program ON hospital_programs(program_id);
CREATE TABLE saved_hospitals (id SERIAL PRIMARY KEY, user_id INT NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  hospital_id INT NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE, UNIQUE (user_id, hospital_id));
CREATE INDEX ix_saved_user ON saved_hospitals(user_id);
CREATE TABLE search_history (id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id) ON DELETE CASCADE,
  search_query VARCHAR(300) NOT NULL, location VARCHAR(120), created_at TIMESTAMP DEFAULT NOW());
CREATE INDEX ix_sh_user ON search_history(user_id);
CREATE INDEX ix_sh_created ON search_history(created_at);
CREATE TABLE corrections (id SERIAL PRIMARY KEY, user_id INT REFERENCES users(id) ON DELETE SET NULL,
  hospital_id INT NOT NULL REFERENCES hospitals(id) ON DELETE CASCADE, message TEXT NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'open', created_at TIMESTAMP DEFAULT NOW());
CREATE INDEX ix_corr_hospital ON corrections(hospital_id);
