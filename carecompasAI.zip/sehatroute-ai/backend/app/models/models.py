from datetime import datetime, timezone

from sqlalchemy import (Boolean, Column, DateTime, Float, ForeignKey, Index, Integer, String, Text,
                        UniqueConstraint)
from sqlalchemy.orm import relationship

from app.database.session import Base


def now():
    return datetime.now(timezone.utc).replace(tzinfo=None)


class User(Base):
    __tablename__ = "users"
    id = Column(Integer, primary_key=True)
    name = Column(String(120), nullable=False)
    email = Column(String(200), unique=True, index=True, nullable=False)
    hashed_password = Column(String(300), nullable=False)
    is_admin = Column(Boolean, default=False, nullable=False)
    created_at = Column(DateTime, default=now, nullable=False)


class Hospital(Base):
    __tablename__ = "hospitals"
    id = Column(Integer, primary_key=True)
    name = Column(String(200), nullable=False, index=True)
    hospital_type = Column(String(30), nullable=False, index=True)  # government | private | semi_government
    address = Column(String(300), nullable=False)
    city = Column(String(80), nullable=False, index=True)
    latitude = Column(Float, nullable=False)
    longitude = Column(Float, nullable=False)
    contact = Column(String(60))
    website = Column(String(200))
    operating_hours = Column(String(120))
    verification_status = Column(String(20), default="unverified", nullable=False, index=True)  # demo | unverified | verified
    location_verified = Column(Boolean, default=False, nullable=False)
    facilities = Column(Text, default="[]")  # JSON list
    emergency_available = Column(Boolean, default=False)
    data_source = Column(String(60), default="demo")
    created_at = Column(DateTime, default=now)

    treatments = relationship("HospitalTreatment", back_populates="hospital", cascade="all, delete-orphan")
    doctors = relationship("Doctor", back_populates="hospital", cascade="all, delete-orphan")
    prices = relationship("TreatmentPrice", back_populates="hospital", cascade="all, delete-orphan")
    programs = relationship("HospitalProgram", back_populates="hospital", cascade="all, delete-orphan")
    __table_args__ = (Index("ix_hospitals_geo", "latitude", "longitude"),)


class Treatment(Base):
    __tablename__ = "treatments"
    id = Column(Integer, primary_key=True)
    treatment_name = Column(String(150), unique=True, nullable=False)
    description = Column(Text)
    medical_category = Column(String(80), nullable=False, index=True)
    specialist = Column(String(80))  # specialist normally required, e.g. "Cardiologist"


class HospitalTreatment(Base):
    __tablename__ = "hospital_treatments"
    id = Column(Integer, primary_key=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False, index=True)
    treatment_id = Column(Integer, ForeignKey("treatments.id", ondelete="CASCADE"), nullable=False, index=True)
    availability_status = Column(String(20), default="available", nullable=False)  # available | limited | unavailable
    hospital = relationship("Hospital", back_populates="treatments")
    treatment = relationship("Treatment")
    __table_args__ = (UniqueConstraint("hospital_id", "treatment_id"),)


class Doctor(Base):
    __tablename__ = "doctors"
    id = Column(Integer, primary_key=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False, index=True)
    name = Column(String(150), nullable=False)
    specialization = Column(String(80), nullable=False, index=True)
    availability_status = Column(String(20), default="available")  # available | limited | unavailable
    hospital = relationship("Hospital", back_populates="doctors")


class TreatmentPrice(Base):
    __tablename__ = "treatment_prices"
    id = Column(Integer, primary_key=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False, index=True)
    treatment_id = Column(Integer, ForeignKey("treatments.id", ondelete="CASCADE"), nullable=False, index=True)
    minimum_price = Column(Float, nullable=False)
    maximum_price = Column(Float, nullable=False)
    last_verified = Column(DateTime)  # NULL = unverified / demo estimate
    hospital = relationship("Hospital", back_populates="prices")
    treatment = relationship("Treatment")
    __table_args__ = (UniqueConstraint("hospital_id", "treatment_id"),)


class HealthcareProgram(Base):
    __tablename__ = "healthcare_programs"
    id = Column(Integer, primary_key=True)
    program_name = Column(String(150), unique=True, nullable=False)
    program_type = Column(String(30), nullable=False)  # government_card | insurance | zakat | welfare | aid
    description = Column(Text)


class HospitalProgram(Base):
    __tablename__ = "hospital_programs"
    id = Column(Integer, primary_key=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False, index=True)
    program_id = Column(Integer, ForeignKey("healthcare_programs.id", ondelete="CASCADE"), nullable=False, index=True)
    acceptance_status = Column(String(20), default="unknown", nullable=False)  # accepted | not_accepted | unknown
    verification_date = Column(DateTime)  # NULL = unverified
    hospital = relationship("Hospital", back_populates="programs")
    program = relationship("HealthcareProgram")
    __table_args__ = (UniqueConstraint("hospital_id", "program_id"),)


class SavedHospital(Base):
    __tablename__ = "saved_hospitals"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), nullable=False, index=True)
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False, index=True)
    __table_args__ = (UniqueConstraint("user_id", "hospital_id"),)


class SearchHistory(Base):
    __tablename__ = "search_history"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="CASCADE"), index=True)
    search_query = Column(String(300), nullable=False)
    location = Column(String(120))
    created_at = Column(DateTime, default=now, index=True)


class Correction(Base):
    __tablename__ = "corrections"
    id = Column(Integer, primary_key=True)
    user_id = Column(Integer, ForeignKey("users.id", ondelete="SET NULL"))
    hospital_id = Column(Integer, ForeignKey("hospitals.id", ondelete="CASCADE"), nullable=False, index=True)
    message = Column(Text, nullable=False)
    status = Column(String(20), default="open", nullable=False)
    created_at = Column(DateTime, default=now)
    hospital = relationship("Hospital")
