import json

from fastapi import HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session, selectinload

from app.ai import nlp, recommender
from app.models.models import now, Hospital, HospitalProgram, HospitalTreatment, SearchHistory, Treatment
from app.schemas.schemas import SearchRequest
from app.services.geo import bbox, haversine

SUPPORT_TYPES = {"government_card", "zakat", "welfare", "aid"}
NOTE_NO_PRICE = "Select a specific treatment to see cost estimates and cost comparison."
SAVINGS_NOTE = ("Estimates only. Actual expenses depend on eligibility, hospital policies and treatment requirements; "
                "figures marked demo are synthetic and savings are not guaranteed.")


def resolve_requirement(db: Session, req: SearchRequest):
    treatments = db.scalars(select(Treatment)).all()
    by_id = {t.id: t for t in treatments}
    text = " ".join(x for x in [req.condition, req.specialist, req.query] if x).strip()
    ctx = {"mode": "none", "treatment_ids": set(), "treatment_names": [], "department": None, "specialist": None,
           "single": False, "label": None, "extraction": None}
    if req.treatment_id:
        t = by_id.get(req.treatment_id)
        if not t:
            raise HTTPException(404, "Treatment not found")
        ctx.update(mode="treatment", treatment_ids={t.id}, treatment_names=[t.treatment_name], department=t.medical_category,
                   specialist=t.specialist, single=True, label=t.treatment_name)
    elif text:
        ex = nlp.extract_requirements(text, treatments)
        ctx["extraction"] = ex
        if not ex["department"]:
            ctx["mode"] = "unrecognized"
            return ctx
        ids = set(ex["treatment_ids"]) or {t.id for t in treatments if t.medical_category == ex["department"]}
        names = ex["treatment_names"] or [t.treatment_name for t in treatments if t.id in ids]
        ctx.update(mode="treatment" if ex["treatment_ids"] else "department", treatment_ids=ids, treatment_names=names,
                   department=ex["department"], specialist=ex["specialist"], single=len(ids) == 1,
                   label=names[0] if len(ids) == 1 else f"{ex['department'].lower()} treatment")
    return ctx


def _programs(h):
    return [{"program_id": p.program_id, "name": p.program.program_name, "type": p.program.program_type,
             "status": p.acceptance_status, "verified": p.verification_date is not None} for p in h.programs]


def build_candidate(h: Hospital, dist: float, ctx):
    tids = ctx["treatment_ids"]
    matched = [ht for ht in h.treatments if ht.treatment_id in tids and ht.availability_status in ("available", "limited")]
    if tids and not matched:
        return None  # mandatory eligibility: must offer the treatment
    compat = spec = None
    if tids:
        compat = 100.0 * sum(1.0 if m.availability_status == "available" else 0.6 for m in matched) / len(tids)
        docs = [d for d in h.doctors if ctx["specialist"] and d.specialization.lower() == ctx["specialist"].lower()
                and d.availability_status != "unavailable"]
        spec = 100.0 if any(d.availability_status == "available" for d in docs) else (50.0 if docs else 0.0)
    price = None
    if ctx["single"]:
        tp = next((p for p in h.prices if p.treatment_id in tids), None)
        if tp:
            price = {"min": tp.minimum_price, "max": tp.maximum_price, "mid": (tp.minimum_price + tp.maximum_price) / 2,
                     "treatment": ctx["label"], "verified": tp.last_verified is not None,
                     "last_verified": tp.last_verified.isoformat() if tp.last_verified else None}
    progs = _programs(h)
    cats = sorted({ht.treatment.medical_category for ht in h.treatments if ht.availability_status != "unavailable"})
    return {"h": h, "hospital_type": h.hospital_type, "distance_km": dist, "compat": compat, "specialist_score": spec,
            "price": price, "programs": progs, "departments": cats, "verification_status": h.verification_status,
            "location_verified": h.location_verified,
            "matched": [{"id": m.treatment_id, "name": m.treatment.treatment_name, "status": m.availability_status} for m in matched],
            "financial_assistance": any(p["type"] in SUPPORT_TYPES and p["status"] == "accepted" for p in progs)}


def to_result(c):
    h = c["h"]
    return {"id": h.id, "name": h.name, "hospital_type": h.hospital_type, "address": h.address, "city": h.city,
            "latitude": h.latitude, "longitude": h.longitude, "distance_km": round(c["distance_km"], 1),
            "location_verified": h.location_verified, "verification_status": h.verification_status,
            "data_source": h.data_source, "contact": h.contact, "website": h.website, "operating_hours": h.operating_hours,
            "hours_verified": h.verification_status == "verified", "emergency_available": h.emergency_available,
            "facilities": json.loads(h.facilities or "[]"), "departments": c["departments"],
            "matched_treatments": c["matched"],
            "specialists": [{"name": d.name, "specialization": d.specialization, "availability": d.availability_status} for d in h.doctors],
            "price": c["price"], "programs": c["programs"], "financial_assistance": c["financial_assistance"],
            "score": c["score"], "breakdown": c["breakdown"], "unscored": c["unscored"],
            "explanation": c["explanation"], "flags": c["flags"]}


def _brief(c):
    h = c["h"]
    return {"id": h.id, "name": h.name, "hospital_type": h.hospital_type, "distance_km": round(c["distance_km"], 1),
            "price": c["price"], "score": c["score"]}


def build_comparison(cands, ctx):
    out = {"eligible_count": len(cands), "disclaimer": SAVINGS_NOTE}
    if not cands:
        return out
    out["best_match"] = _brief(max(cands, key=lambda c: c["score"]))
    out["nearest"] = _brief(min(cands, key=lambda c: c["distance_km"]))
    sup = [c for c in cands if c["financial_assistance"]]
    if sup:
        out["with_financial_support"] = _brief(max(sup, key=lambda c: c["score"]))
    if not ctx["single"]:
        out["note"] = NOTE_NO_PRICE
        return out
    priced = [c for c in cands if c["price"]]
    if priced:
        out["lowest_cost"] = _brief(min(priced, key=lambda c: c["price"]["mid"]))
    if len(priced) >= 2:
        hi = max(priced, key=lambda c: c["price"]["mid"])["price"]["mid"]
        lo = min(priced, key=lambda c: c["price"]["mid"])["price"]["mid"]
        sv = {"treatment": ctx["label"], "highest_estimate": hi, "lowest_estimate": lo, "potential_difference": hi - lo}
        priv = [c["price"]["mid"] for c in priced if c["hospital_type"] == "private"]
        gov = [c["price"]["mid"] for c in priced if c["hospital_type"] != "private"]
        if priv and gov:
            sv.update(avg_private_estimate=sum(priv) / len(priv), lowest_supported_estimate=min(gov),
                      private_vs_supported_difference=max(0.0, sum(priv) / len(priv) - min(gov)))
        out["savings"] = sv
    return out


def run_search(db: Session, req: SearchRequest, user=None):
    ctx = resolve_requirement(db, req)
    base = {"query": {"lat": req.lat, "lng": req.lng, "radius_km": req.radius_km, "mode": ctx["mode"],
                      "treatment": ctx["label"], "department": ctx["department"], "specialist": ctx["specialist"],
                      "extraction": ctx["extraction"]},
            "total": 0, "page": req.page, "page_size": req.page_size, "results": [], "comparison": {"eligible_count": 0}}
    if ctx["mode"] == "unrecognized":
        base["message"] = ("We could not map that text to a treatment or specialist in our catalogue. Try a treatment "
                           "name (e.g. angioplasty, dialysis) or choose from the lists. This tool does not diagnose conditions.")
        return base
    a, b, c_, d = bbox(req.lat, req.lng, req.radius_km)
    q = (select(Hospital).where(Hospital.latitude.between(a, b), Hospital.longitude.between(c_, d))
         .options(selectinload(Hospital.treatments).selectinload(HospitalTreatment.treatment), selectinload(Hospital.doctors),
                  selectinload(Hospital.prices), selectinload(Hospital.programs).selectinload(HospitalProgram.program)))
    if req.hospital_types:
        q = q.where(Hospital.hospital_type.in_(req.hospital_types))
    cands = []
    for h in db.scalars(q).all():
        dist = haversine(req.lat, req.lng, h.latitude, h.longitude)
        if dist > req.radius_km:
            continue
        c = build_candidate(h, dist, ctx)
        if c:
            cands.append(c)
    if req.program_ids:
        ids = set(req.program_ids)
        cands = [c for c in cands if any(p["program_id"] in ids and p["status"] == "accepted" for p in c["programs"])]
    if req.financial_assistance:
        cands = [c for c in cands if c["financial_assistance"]]
    if req.max_budget is not None and ctx["single"]:
        cands = [c for c in cands if c["price"] is None or c["price"]["min"] <= req.max_budget]
    recommender.score_candidates(cands, ctx, req.weights, req.max_budget, req.program_ids, req.radius_km)
    if req.sort == "distance":
        cands.sort(key=lambda c: c["distance_km"])
    elif req.sort == "cost":
        cands.sort(key=lambda c: (c["price"] is None, c["price"]["mid"] if c["price"] else 0, -c["score"]))
    elif req.sort == "government":
        rank = {"government": 0, "semi_government": 1, "private": 2}
        cands.sort(key=lambda c: (rank.get(c["hospital_type"], 3), -c["score"]))
    else:
        cands.sort(key=lambda c: -c["score"])
    base["comparison"] = build_comparison(cands, ctx)
    base["total"] = len(cands)
    start = (req.page - 1) * req.page_size
    base["results"] = [to_result(c) for c in cands[start:start + req.page_size]]
    if not cands:
        base["message"] = "No hospitals in this radius match the requirement. Try a larger radius or different filters."
    if user is not None and req.page == 1:
        label = ctx["label"] or ctx["department"] or (req.query or req.condition or "All hospitals")
        db.add(SearchHistory(user_id=user.id, search_query=str(label)[:300],
                             location=f"{req.location_label or 'custom'} ({req.lat:.3f},{req.lng:.3f}) r={req.radius_km}km"[:120],
                             created_at=now()))
        db.commit()
    return base
