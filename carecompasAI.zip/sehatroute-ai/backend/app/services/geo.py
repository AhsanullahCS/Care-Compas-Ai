import math

R_KM = 6371.0088

AREAS = [
    {"name": "Islamabad (Centre)", "lat": 33.6844, "lng": 73.0479},
    {"name": "Blue Area, Islamabad", "lat": 33.7100, "lng": 73.0600},
    {"name": "Rawalpindi (Saddar)", "lat": 33.5970, "lng": 73.0480},
    {"name": "Bahria Town / DHA", "lat": 33.5400, "lng": 73.1100},
    {"name": "Taxila", "lat": 33.7460, "lng": 72.8250},
    {"name": "Wah Cantt", "lat": 33.7700, "lng": 72.7500},
    {"name": "Murree", "lat": 33.9070, "lng": 73.3900},
]


def haversine(lat1, lng1, lat2, lng2):
    p1, p2 = math.radians(lat1), math.radians(lat2)
    dp, dl = p2 - p1, math.radians(lng2 - lng1)
    a = math.sin(dp / 2) ** 2 + math.cos(p1) * math.cos(p2) * math.sin(dl / 2) ** 2
    return 2 * R_KM * math.asin(math.sqrt(a))


def bbox(lat, lng, radius_km):
    dlat = radius_km / 110.574
    dlng = radius_km / (111.320 * max(math.cos(math.radians(lat)), 0.01))
    return lat - dlat, lat + dlat, lng - dlng, lng + dlng
