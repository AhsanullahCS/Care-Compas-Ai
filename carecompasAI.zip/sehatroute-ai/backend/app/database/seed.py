import json
import sys
from datetime import datetime

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.config import settings
from app.core.security import hash_password
from app.database.session import Base, SessionLocal, engine
from app.models import models as m


def ensure_users(db: Session):
    for name, email, pw, admin in [("Demo Admin", settings.ADMIN_EMAIL, settings.ADMIN_PASSWORD, True),
                                   ("Demo Patient", settings.DEMO_USER_EMAIL, settings.DEMO_USER_PASSWORD, False)]:
        if not db.scalar(select(m.User).where(m.User.email == email)):
            db.add(m.User(name=name, email=email, hashed_password=hash_password(pw), is_admin=admin))
    db.commit()


def seed(db: Session, force=False) -> bool:
    ensure_users(db)
    if db.scalar(select(func.count(m.Hospital.id))) and not force:
        return False
    data = json.load(open(settings.DATASET_PATH, encoding="utf-8"))
    tmap, pmap = {}, {}
    for t in data["treatments"]:
        row = m.Treatment(treatment_name=t["name"], description=t["description"], medical_category=t["category"], specialist=t["specialist"])
        db.add(row)
        tmap[t["name"]] = row
    for p in data["programs"]:
        row = m.HealthcareProgram(program_name=p["name"], program_type=p["type"], description=p["description"])
        db.add(row)
        pmap[p["name"]] = row
    db.flush()
    for h in data["hospitals"]:
        row = m.Hospital(name=h["name"], hospital_type=h["type"], address=h["address"], city=h["city"], latitude=h["lat"],
                         longitude=h["lng"], contact=h["contact"], website=h.get("website"), operating_hours=h["hours"],
                         verification_status="demo", location_verified=False, facilities=json.dumps(h["facilities"]),
                         emergency_available=h["emergency"], data_source="demo")
        db.add(row)
        db.flush()
        for t in h["treatments"]:
            db.add(m.HospitalTreatment(hospital_id=row.id, treatment_id=tmap[t["name"]].id, availability_status=t["status"]))
        for d in h["doctors"]:
            db.add(m.Doctor(hospital_id=row.id, name=d["name"], specialization=d["specialization"], availability_status=d["status"]))
        for p in h["prices"]:
            db.add(m.TreatmentPrice(hospital_id=row.id, treatment_id=tmap[p["treatment"]].id, minimum_price=p["min"], maximum_price=p["max"]))
        for p in h["programs"]:
            db.add(m.HospitalProgram(hospital_id=row.id, program_id=pmap[p["program"]].id, acceptance_status=p["status"]))
    db.commit()
    return True


if __name__ == "__main__":
    if "--reset" in sys.argv:
        Base.metadata.drop_all(engine)
    Base.metadata.create_all(engine)
    with SessionLocal() as db:
        print("seeded" if seed(db, force="--reset" in sys.argv) else "already seeded (use --reset to rebuild)")
