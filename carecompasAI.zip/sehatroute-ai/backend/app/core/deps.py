from fastapi import Depends, HTTPException
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
from sqlalchemy.orm import Session

from app.core.security import decode_token
from app.database.session import get_db
from app.models.models import User

bearer = HTTPBearer(auto_error=False)


def get_optional_user(cred: HTTPAuthorizationCredentials | None = Depends(bearer), db: Session = Depends(get_db)):
    if not cred:
        return None
    uid = decode_token(cred.credentials)
    return db.get(User, uid) if uid else None


def get_current_user(user: User | None = Depends(get_optional_user)):
    if not user:
        raise HTTPException(401, "Not authenticated", headers={"WWW-Authenticate": "Bearer"})
    return user


def require_admin(user: User = Depends(get_current_user)):
    if not user.is_admin:
        raise HTTPException(403, "Administrator access required")
    return user
