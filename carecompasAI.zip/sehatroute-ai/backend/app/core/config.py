import os
from pathlib import Path
from dotenv import load_dotenv

BASE_DIR = Path(__file__).resolve().parents[2]  # backend/
ROOT_DIR = BASE_DIR.parent
load_dotenv(ROOT_DIR / ".env")
load_dotenv(BASE_DIR / ".env")


def _bool(v, default=False):
    return default if v is None else v.strip().lower() in ("1", "true", "yes")


class Settings:
    DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{BASE_DIR / 'sehatroute.db'}")
    SECRET_KEY = os.getenv("SECRET_KEY", "dev-only-secret-change-me-please-0123456789")
    ACCESS_TOKEN_EXPIRE_MINUTES = int(os.getenv("ACCESS_TOKEN_EXPIRE_MINUTES", "720"))
    CORS_ORIGINS = [o.strip() for o in os.getenv("CORS_ORIGINS", "http://localhost:5173,http://127.0.0.1:5173").split(",") if o.strip()]
    RATE_LIMIT_PER_MINUTE = int(os.getenv("RATE_LIMIT_PER_MINUTE", "180"))
    AUTH_RATE_LIMIT_PER_MINUTE = int(os.getenv("AUTH_RATE_LIMIT_PER_MINUTE", "20"))
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-2.0-flash")
    AUTO_SEED = _bool(os.getenv("AUTO_SEED"), True)
    ADMIN_EMAIL = os.getenv("ADMIN_EMAIL", "admin@sehatroute.demo")
    ADMIN_PASSWORD = os.getenv("ADMIN_PASSWORD", "Admin@12345")
    DEMO_USER_EMAIL = os.getenv("DEMO_USER_EMAIL", "patient@sehatroute.demo")
    DEMO_USER_PASSWORD = os.getenv("DEMO_USER_PASSWORD", "Patient@12345")
    DATASET_PATH = os.getenv("DATASET_PATH", str(ROOT_DIR / "dataset" / "demo_hospitals.json"))


settings = Settings()
