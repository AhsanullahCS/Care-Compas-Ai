from datetime import datetime
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, field_validator

EMAIL_RE = r"^[^@\s]+@[^@\s]+\.[^@\s]+$"
HType = Literal["government", "private", "semi_government"]
Avail = Literal["available", "limited", "unavailable"]


class RegisterIn(BaseModel):
    name: str = Field(min_length=2, max_length=120)
    email: str = Field(pattern=EMAIL_RE, max_length=200)
    password: str = Field(min_length=8, max_length=128)


class LoginIn(BaseModel):
    email: str = Field(pattern=EMAIL_RE, max_length=200)
    password: str = Field(min_length=1, max_length=128)


class UserOut(BaseModel):
    model_config = ConfigDict(from_attributes=True)
    id: int
    name: str
    email: str
    is_admin: bool
    created_at: datetime


class TokenOut(BaseModel):
    access_token: str
    token_type: str = "bearer"
    user: UserOut


class SearchRequest(BaseModel):
    lat: float = Field(33.6844, ge=-90, le=90)
    lng: float = Field(73.0479, ge=-180, le=180)
    radius_km: int = Field(50, ge=1, le=200)
    treatment_id: int | None = None
    specialist: str | None = Field(None, max_length=80)
    condition: str | None = Field(None, max_length=200)
    query: str | None = Field(None, max_length=1000)
    hospital_types: list[HType] = []
    program_ids: list[int] = []
    max_budget: float | None = Field(None, ge=0)
    financial_assistance: bool = False
    sort: Literal["ai", "distance", "cost", "government"] = "ai"
    weights: dict[str, float] | None = None
    location_label: str | None = Field(None, max_length=100)
    page: int = Field(1, ge=1)
    page_size: int = Field(20, ge=1, le=200)


class ExplainIn(SearchRequest):
    hospital_id: int


class ReferralIn(BaseModel):
    text: str = Field(min_length=3, max_length=2000)
    lat: float | None = Field(None, ge=-90, le=90)
    lng: float | None = Field(None, ge=-180, le=180)
    radius_km: int = Field(50, ge=1, le=200)


class AssistantIn(BaseModel):
    message: str = Field(min_length=1, max_length=1000)
    lat: float | None = Field(None, ge=-90, le=90)
    lng: float | None = Field(None, ge=-180, le=180)
    radius_km: int = Field(50, ge=1, le=200)


class SavedIn(BaseModel):
    hospital_id: int


class CorrectionIn(BaseModel):
    hospital_id: int
    message: str = Field(min_length=5, max_length=2000)


class HospitalIn(BaseModel):
    name: str = Field(min_length=2, max_length=200)
    hospital_type: HType
    address: str = Field(min_length=2, max_length=300)
    city: str = Field(min_length=2, max_length=80)
    latitude: float = Field(ge=-90, le=90)
    longitude: float = Field(ge=-180, le=180)
    contact: str | None = None
    website: str | None = None
    operating_hours: str | None = None
    facilities: list[str] = []
    emergency_available: bool = False
    location_verified: bool = False


class HospitalUpdate(BaseModel):
    name: str | None = None
    hospital_type: HType | None = None
    address: str | None = None
    city: str | None = None
    latitude: float | None = Field(None, ge=-90, le=90)
    longitude: float | None = Field(None, ge=-180, le=180)
    contact: str | None = None
    website: str | None = None
    operating_hours: str | None = None
    facilities: list[str] | None = None
    emergency_available: bool | None = None
    location_verified: bool | None = None


class TreatmentIn(BaseModel):
    treatment_name: str = Field(min_length=2, max_length=150)
    description: str | None = None
    medical_category: str = Field(min_length=2, max_length=80)
    specialist: str | None = None


class PriceIn(BaseModel):
    hospital_id: int
    treatment_id: int
    minimum_price: float = Field(ge=0)
    maximum_price: float = Field(ge=0)
    verified: bool = False

    @field_validator("maximum_price")
    @classmethod
    def _max_ge_min(cls, v, info):
        if "minimum_price" in info.data and v < info.data["minimum_price"]:
            raise ValueError("maximum_price must be >= minimum_price")
        return v


class HospitalTreatmentIn(BaseModel):
    hospital_id: int
    treatment_id: int
    availability_status: Avail = "available"


class DoctorIn(BaseModel):
    hospital_id: int
    name: str = Field(min_length=2, max_length=150)
    specialization: str = Field(min_length=2, max_length=80)
    availability_status: Avail = "available"


class ProgramIn(BaseModel):
    program_name: str = Field(min_length=2, max_length=150)
    program_type: Literal["government_card", "insurance", "zakat", "welfare", "aid"]
    description: str | None = None


class HospitalProgramIn(BaseModel):
    hospital_id: int
    program_id: int
    acceptance_status: Literal["accepted", "not_accepted", "unknown"]
    verified: bool = False
