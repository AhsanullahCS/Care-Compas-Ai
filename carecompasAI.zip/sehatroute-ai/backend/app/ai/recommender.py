"""Transparent weighted hospital ranking.

Eligibility (done BEFORE scoring, in services/search.py): a hospital must offer the requested
treatment(s). A cheap or close hospital that does not offer the treatment is never returned.

Every factor is normalised to 0-100:
  treatment     100 = treatment available, 60 = limited capacity (department searches: share offered)
  specialist    100 = matching specialist listed & available, 50 = limited, 0 = none listed
  distance      100 at the search point falling linearly to 0 at the radius edge
  affordability relative to the eligible set (cheapest = 100); only for a single specific treatment;
                over-budget prices are multiplied by 0.4; missing price = 0 (never a positive)
  government    0.6*hospital type (govt 100 / semi 60 / private 0) + 0.4*financial-assistance programs
                (blended with the patient's selected card when one is chosen)
  insurance     acceptance of the selected card/insurance (or best generic card/insurance)
Program acceptance: verified = 100, demo/unverified "accepted" = 70, anything else = 0.
Factors that cannot be computed (e.g. no treatment chosen) are dropped and weights renormalised.
"""
DEFAULT_WEIGHTS = {"treatment": 0.30, "specialist": 0.20, "distance": 0.15, "affordability": 0.15,
                   "government": 0.15, "insurance": 0.05}
ASSIST_TYPES = {"government_card", "zakat", "welfare", "aid"}
TYPE_SCORE = {"government": 100, "semi_government": 60, "private": 0}


def normalise_weights(user=None):
    w = dict(DEFAULT_WEIGHTS)
    for k, v in (user or {}).items():
        if k in w and isinstance(v, (int, float)) and v >= 0:
            w[k] = float(v)
    s = sum(w.values())
    return {k: v / s for k, v in w.items()} if s > 0 else dict(DEFAULT_WEIGHTS)


def program_score(p):
    if p["status"] != "accepted":
        return 0
    return 100 if p["verified"] else 70


def _best(programs, pred):
    return max([program_score(p) for p in programs if pred(p)], default=0)


def score_candidates(cands, ctx, weights=None, budget=None, selected=None, radius=50):
    w = normalise_weights(weights)
    selected = set(selected or [])
    single = ctx.get("single")
    mids = [c["price"]["mid"] for c in cands if c.get("price")]
    lo, hi = (min(mids), max(mids)) if mids else (0, 0)
    for c in cands:
        f = {"treatment": c["compat"], "specialist": c["specialist_score"],
             "distance": max(0.0, 100 * (1 - c["distance_km"] / max(radius, 1)))}
        if single:
            if not c["price"]:
                f["affordability"] = 0.0
            else:
                a = 100.0 if hi == lo else 100 * (hi - c["price"]["mid"]) / (hi - lo)
                if budget is not None and c["price"]["mid"] > budget:
                    a *= 0.4
                f["affordability"] = a
        else:
            f["affordability"] = None
        progs = c["programs"]
        type_s = TYPE_SCORE.get(c["hospital_type"], 0)
        assist = _best(progs, lambda p: p["type"] in ASSIST_TYPES)
        if selected:
            sel = _best(progs, lambda p: p["program_id"] in selected)
            f["government"] = 0.4 * type_s + 0.3 * assist + 0.3 * sel
            f["insurance"] = float(sel)
        else:
            f["government"] = 0.6 * type_s + 0.4 * assist
            f["insurance"] = float(_best(progs, lambda p: p["type"] in ("insurance", "government_card")))
        active = {k: v for k, v in f.items() if v is not None}
        wsum = sum(w[k] for k in active) or 1.0
        c["score"] = round(sum(w[k] * v for k, v in active.items()) / wsum, 1)
        c["breakdown"] = {k: {"score": round(v, 1), "weight": round(100 * w[k] / wsum, 1),
                              "contribution": round(w[k] * v / wsum, 1)} for k, v in active.items()}
        c["unscored"] = [k for k, v in f.items() if v is None]
        c["explanation"] = explain(c, ctx, selected)
        c["flags"] = flags(c, ctx)
    return cands


def explain(c, ctx, selected):
    b, parts = c["breakdown"], []
    what = ctx.get("label") or "the required treatment"
    if c["compat"] is not None:
        parts.append(f"offers {what}" + (" (with limited capacity)" if c["compat"] < 100 and ctx.get("single") else ""))
    if c["specialist_score"] == 100:
        parts.append(f"lists an available {ctx['specialist']}")
    elif c["specialist_score"] == 50:
        parts.append(f"lists a {ctx['specialist']} with limited availability")
    parts.append(f"is approximately {c['distance_km']:.0f} km away")
    if c["price"]:
        if b.get("affordability", {}).get("score", 0) >= 70:
            parts.append("has a comparatively low estimated cost (demo estimate)")
        else:
            parts.append(f"has an estimated cost of PKR {c['price']['min']:,.0f}-{c['price']['max']:,.0f} (demo estimate)")
    if c["hospital_type"] == "government":
        parts.append("is a government hospital")
    if selected:
        names = [p["name"] for p in c["programs"] if p["program_id"] in selected and p["status"] == "accepted"]
        if names:
            parts.append("lists " + ", ".join(names) + " as accepted (not verified)" if not any(
                p["verified"] for p in c["programs"] if p["program_id"] in selected) else "has verified acceptance of " + ", ".join(names))
    text = "Recommended because this hospital " + (", ".join(parts[:-1]) + ", and " + parts[-1] if len(parts) > 1 else parts[0]) + "."
    if c["verification_status"] != "verified":
        text += " This listing is demo/unverified data: confirm availability, price and scheme acceptance with the hospital."
    return text


def flags(c, ctx):
    out = []
    if c["verification_status"] != "verified":
        out.append("demo_data")
    if not c["location_verified"]:
        out.append("location_approximate")
    if ctx.get("single") and not c["price"]:
        out.append("price_unavailable")
    elif c["price"] and not c["price"]["verified"]:
        out.append("price_unverified")
    return out
