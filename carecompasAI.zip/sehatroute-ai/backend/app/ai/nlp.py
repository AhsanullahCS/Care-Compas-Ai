"""Referral / condition text -> required department, specialist and treatment.

This is NOT diagnosis: it only maps words a patient or referral letter already contains
(e.g. "angioplasty", "dialysis") onto the platform's catalogue. A rule-based extractor is always
available; if GEMINI_API_KEY is set, Gemini is tried first and its output is validated against the
catalogue (unknown values are discarded) before use.
"""
import json
import logging

import httpx

from app.core.config import settings

log = logging.getLogger("sehatroute.nlp")

DEPT_KEYWORDS = {
    "Cardiology": ["heart", "cardiac", "cardio", "angio", "bypass", "stent", "cabg", "coronary", "blockage"],
    "Nephrology": ["kidney", "renal", "dialysis", "nephro", "transplant"],
    "Oncology": ["cancer", "chemo", "radiotherapy", "tumor", "tumour", "oncolog", "radiation"],
    "Orthopedics": ["knee", "fracture", "bone", "spine", "orthop", "joint", "hip", "broken"],
    "Neurology": ["stroke", "epilep", "seizure", "neuro", "brain", "paralysis"],
    "Gastroenterology": ["liver", "endoscop", "stomach", "gastro", "hepat", "colon", "ulcer"],
    "Urology": ["stone", "lithotrip", "prostate", "urolog", "urinary", "bladder"],
    "Gynecology": ["c-section", "cesarean", "caesarean", "pregnan", "delivery", "gynae", "gynec", "obstet", "maternity"],
    "Ophthalmology": ["cataract", "eye", "ophthal", "retina", "vision"],
    "General Surgery": ["appendix", "appendic", "hernia", "gallbladder", "surgery", "surgeon"],
}
TREATMENT_KEYWORDS = {
    "Angiography": ["angiogra"],
    "Angioplasty (Stent)": ["angioplast", "stent"],
    "CABG (Bypass Surgery)": ["cabg", "bypass"],
    "Hemodialysis": ["dialysis", "haemodialysis", "hemodialysis"],
    "Kidney Transplant": ["kidney transplant", "renal transplant"],
    "Chemotherapy": ["chemo"],
    "Radiotherapy": ["radiotherapy", "radiation therapy"],
    "Knee Replacement": ["knee replacement", "knee arthroplasty"],
    "Fracture Fixation": ["fracture", "broken bone"],
    "Spine Surgery": ["spine surgery", "spinal surgery", "disc surgery"],
    "Stroke Care": ["stroke"],
    "Epilepsy Management": ["epilep", "seizure"],
    "Endoscopy": ["endoscop"],
    "Liver Disease Management": ["liver"],
    "Lithotripsy": ["lithotrip", "kidney stone", "stone"],
    "Prostate Surgery": ["prostate"],
    "C-Section": ["c-section", "cesarean", "caesarean"],
    "Cataract Surgery": ["cataract"],
    "Appendectomy": ["appendectomy", "appendix", "appendicitis"],
    "Hernia Repair": ["hernia"],
}
SPECIALIST_BY_DEPT = {
    "Cardiology": "Cardiologist", "Nephrology": "Nephrologist", "Oncology": "Oncologist",
    "Orthopedics": "Orthopedic Surgeon", "Neurology": "Neurologist", "Gastroenterology": "Gastroenterologist",
    "Urology": "Urologist", "Gynecology": "Gynecologist", "Ophthalmology": "Ophthalmologist",
    "General Surgery": "General Surgeon",
}


def _keyword_extract(text, treatments):
    t = text.lower()
    by_name = {tr.treatment_name: tr for tr in treatments}
    ids, names = [], []
    for name, kws in TREATMENT_KEYWORDS.items():
        if name in by_name and any(k in t for k in kws):
            ids.append(by_name[name].id)
            names.append(name)
    dept = None
    if names:
        cats = [by_name[n].medical_category for n in names]
        dept = max(set(cats), key=cats.count)
        ids = [by_name[n].id for n in names if by_name[n].medical_category == dept]
        names = [n for n in names if by_name[n].medical_category == dept]
    else:
        scores = {d: sum(k in t for k in kws) for d, kws in DEPT_KEYWORDS.items()}
        best = max(scores, key=scores.get)
        dept = best if scores[best] > 0 else None
    return {"department": dept, "specialist": SPECIALIST_BY_DEPT.get(dept), "treatment_ids": ids,
            "treatment_names": names, "method": "keyword",
            "confidence": "high" if ids else ("medium" if dept else "none")}


def _gemini_extract(text, treatments):
    if not settings.GEMINI_API_KEY:
        return None
    names = [t.treatment_name for t in treatments]
    prompt = ("Extract only what the text explicitly states. Do NOT diagnose. Return JSON "
              '{"department": one of ' + json.dumps(list(SPECIALIST_BY_DEPT)) + ' or null, "treatments": subset of '
              + json.dumps(names) + '}. Text: ' + text[:1500])
    try:
        url = f"https://generativelanguage.googleapis.com/v1beta/models/{settings.GEMINI_MODEL}:generateContent"
        r = httpx.post(url, params={"key": settings.GEMINI_API_KEY}, timeout=8, json={
            "contents": [{"parts": [{"text": prompt}]}], "generationConfig": {"responseMimeType": "application/json"}})
        r.raise_for_status()
        out = json.loads(r.json()["candidates"][0]["content"]["parts"][0]["text"])
    except Exception as e:  # network/format problems -> fall back silently
        log.warning("Gemini extraction failed: %s", e)
        return None
    by_name = {t.treatment_name: t for t in treatments}
    picked = [by_name[n] for n in out.get("treatments", []) if n in by_name]
    dept = out.get("department") if out.get("department") in SPECIALIST_BY_DEPT else None
    if picked:
        dept = picked[0].medical_category
    if not (picked or dept):
        return None
    return {"department": dept, "specialist": SPECIALIST_BY_DEPT.get(dept), "treatment_ids": [t.id for t in picked],
            "treatment_names": [t.treatment_name for t in picked], "method": "gemini",
            "confidence": "high" if picked else "medium"}


def extract_requirements(text, treatments):
    return _gemini_extract(text, treatments) or _keyword_extract(text, treatments)
