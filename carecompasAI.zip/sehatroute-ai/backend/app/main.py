import logging
import time
from contextlib import asynccontextmanager

from fastapi import FastAPI, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse

from app.api import admin, ai, auth, hospitals
from app.core.config import settings
from app.core.ratelimit import RateLimitMiddleware
from app.database.seed import ensure_users, seed
from app.database.session import Base, SessionLocal, engine

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(name)s: %(message)s")
log = logging.getLogger("sehatroute")


@asynccontextmanager
async def lifespan(_: FastAPI):
    Base.metadata.create_all(engine)
    if settings.AUTO_SEED:
        with SessionLocal() as db:
            if seed(db):
                log.info("Seeded demo dataset (synthetic data)")
            else:
                ensure_users(db)
    yield


app = FastAPI(title="SehatRoute AI API", version="1.0.0", lifespan=lifespan,
              description="Healthcare access & hospital recommendation API. Demo data is synthetic and clearly labelled. "
                          "Not a diagnostic tool; not a substitute for professional medical advice.")
app.add_middleware(RateLimitMiddleware)
app.add_middleware(CORSMiddleware, allow_origins=settings.CORS_ORIGINS, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])


@app.middleware("http")
async def log_requests(request: Request, call_next):
    start = time.time()
    response = await call_next(request)
    log.info("%s %s -> %s (%.0f ms)", request.method, request.url.path, response.status_code, (time.time() - start) * 1000)
    return response


@app.exception_handler(RequestValidationError)
async def validation_handler(_, exc: RequestValidationError):
    msgs = [f"{'.'.join(str(p) for p in e['loc'] if p != 'body')}: {e['msg']}" for e in exc.errors()]
    return JSONResponse({"detail": "; ".join(msgs)}, status_code=422)


@app.exception_handler(Exception)
async def unhandled(_, exc: Exception):
    log.exception("Unhandled error: %s", exc)
    return JSONResponse({"detail": "Internal server error"}, status_code=500)


@app.get("/api/health", tags=["meta"])
def health():
    return {"status": "ok"}


for r in (auth.router, hospitals.router, ai.router, admin.router):
    app.include_router(r)
