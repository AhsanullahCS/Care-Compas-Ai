import json

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select
from sqlalchemy.orm import Session, selectinload

from app.ai.recommender import DEFAULT_WEIGHTS
from app.core.deps import get_current_user, get_optional_user
from app.database.session import get_db
from app.models.models import (Correction, HealthcareProgram, Hospital, HospitalProgram, HospitalTreatment, SavedHospital,
                               SearchHistory, Treatment, TreatmentPrice)
from app.schemas.schemas import CorrectionIn, SavedIn, SearchRequest
from app.services.geo import AREAS
from app.services.search import run_search

router = APIRouter(prefix="/api", tags=["hospitals"])
DEMO_NOTE = "Demo/unverified data. Confirm with the hospital before making decisions."


def summary(h: Hospital):
    return {"id": h.id, "name": h.name, "hospital_type": h.hospital_type, "address": h.address, "city": h.city,
            "latitude": h.latitude, "longitude": h.longitude, "contact": h.contact, "website": h.website,
            "operating_hours": h.operating_hours, "hours_verified": h.verification_status == "verified",
            "verification_status": h.verification_status, "location_verified": h.location_verified,
            "emergency_available": h.emergency_available, "facilities": json.loads(h.facilities or "[]"),
            "data_source": h.data_source}


def prog_rows(h):
    return [{"program_id": p.program_id, "name": p.program.program_name, "type": p.program.program_type,
             "status": p.acceptance_status, "verified": p.verification_date is not None,
             "verification_date": p.verification_date.isoformat() if p.verification_date else None} for p in h.programs]


def load_hospital(db, hospital_id):
    h = db.scalar(select(Hospital).where(Hospital.id == hospital_id).options(
        selectinload(Hospital.treatments).selectinload(HospitalTreatment.treatment), selectinload(Hospital.doctors),
        selectinload(Hospital.prices), selectinload(Hospital.programs).selectinload(HospitalProgram.program)))
    if not h:
        raise HTTPException(404, "Hospital not found")
    return h


@router.get("/hospitals")
def list_hospitals(q: str | None = None, city: str | None = None, hospital_type: str | None = None,
                   verification_status: str | None = None, page: int = Query(1, ge=1),
                   page_size: int = Query(20, ge=1, le=200), db: Session = Depends(get_db)):
    stmt = select(Hospital)
    if q:
        stmt = stmt.where(Hospital.name.ilike(f"%{q}%"))
    if city:
        stmt = stmt.where(Hospital.city.ilike(city))
    if hospital_type:
        stmt = stmt.where(Hospital.hospital_type == hospital_type)
    if verification_status:
        stmt = stmt.where(Hospital.verification_status == verification_status)
    total = db.scalar(select(func.count()).select_from(stmt.subquery()))
    rows = db.scalars(stmt.order_by(Hospital.name).offset((page - 1) * page_size).limit(page_size)).all()
    return {"total": total, "page": page, "page_size": page_size, "items": [summary(h) for h in rows]}


@router.get("/hospitals/nearby")
def nearby(lat: float = Query(..., ge=-90, le=90), lng: float = Query(..., ge=-180, le=180),
           radius_km: int = Query(25, ge=1, le=200), db: Session = Depends(get_db)):
    return run_search(db, SearchRequest(lat=lat, lng=lng, radius_km=radius_km, page_size=200, sort="distance"))


@router.get("/hospitals/{hospital_id}")
def hospital_detail(hospital_id: int, db: Session = Depends(get_db)):
    h = load_hospital(db, hospital_id)
    prices = {p.treatment_id: p for p in h.prices}
    treatments = []
    for ht in sorted(h.treatments, key=lambda x: (x.treatment.medical_category, x.treatment.treatment_name)):
        p = prices.get(ht.treatment_id)
        treatments.append({"id": ht.treatment_id, "name": ht.treatment.treatment_name, "category": ht.treatment.medical_category,
                           "specialist": ht.treatment.specialist, "status": ht.availability_status,
                           "price": {"min": p.minimum_price, "max": p.maximum_price, "verified": p.last_verified is not None,
                                     "last_verified": p.last_verified.isoformat() if p.last_verified else None} if p else None})
    out = summary(h)
    out.update(departments=sorted({t["category"] for t in treatments if t["status"] != "unavailable"}), treatments=treatments,
               doctors=[{"id": d.id, "name": d.name, "specialization": d.specialization, "availability": d.availability_status}
                        for d in h.doctors], programs=prog_rows(h),
               notice=None if h.verification_status == "verified" else DEMO_NOTE)
    return out


@router.get("/hospitals/{hospital_id}/programs")
def hospital_programs(hospital_id: int, db: Session = Depends(get_db)):
    return prog_rows(load_hospital(db, hospital_id))


@router.post("/search/hospitals")
def search_hospitals(body: SearchRequest, db: Session = Depends(get_db), user=Depends(get_optional_user)):
    return run_search(db, body, user)


@router.get("/search/filters")
def search_filters(db: Session = Depends(get_db)):
    treatments = db.scalars(select(Treatment).order_by(Treatment.medical_category, Treatment.treatment_name)).all()
    programs = db.scalars(select(HealthcareProgram).order_by(HealthcareProgram.id)).all()
    return {"radii": [10, 25, 50, 100, 200], "hospital_types": ["government", "private", "semi_government"],
            "sort_options": [{"value": "ai", "label": "Best AI recommendation"}, {"value": "distance", "label": "Nearest hospital"},
                             {"value": "cost", "label": "Lowest estimated cost"}, {"value": "government", "label": "Government-supported"}],
            "categories": sorted({t.medical_category for t in treatments}),
            "specialists": sorted({t.specialist for t in treatments if t.specialist}),
            "treatments": [{"id": t.id, "name": t.treatment_name, "category": t.medical_category, "specialist": t.specialist} for t in treatments],
            "programs": [{"id": p.id, "name": p.program_name, "type": p.program_type, "description": p.description} for p in programs],
            "areas": AREAS, "default_weights": DEFAULT_WEIGHTS}


@router.get("/search/history")
def search_history(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.scalars(select(SearchHistory).where(SearchHistory.user_id == user.id).order_by(SearchHistory.created_at.desc()).limit(10)).all()
    return [{"id": r.id, "search_query": r.search_query, "location": r.location, "created_at": r.created_at.isoformat()} for r in rows]


@router.get("/stats")
def public_stats(db: Session = Depends(get_db)):
    c = lambda model: db.scalar(select(func.count()).select_from(model))  # noqa: E731
    return {"hospitals": c(Hospital), "treatments": c(Treatment), "programs": c(HealthcareProgram),
            "verified_hospitals": db.scalar(select(func.count()).select_from(Hospital).where(Hospital.verification_status == "verified")),
            "data_note": "Statistics describe the platform's current dataset (demo data unless marked verified)."}


@router.get("/programs")
def programs(db: Session = Depends(get_db)):
    return [{"id": p.id, "program_name": p.program_name, "program_type": p.program_type, "description": p.description}
            for p in db.scalars(select(HealthcareProgram).order_by(HealthcareProgram.id)).all()]


@router.get("/treatments")
def treatments(category: str | None = None, db: Session = Depends(get_db)):
    stmt = select(Treatment).order_by(Treatment.medical_category, Treatment.treatment_name)
    if category:
        stmt = stmt.where(Treatment.medical_category.ilike(category))
    return [{"id": t.id, "treatment_name": t.treatment_name, "description": t.description, "medical_category": t.medical_category,
             "specialist": t.specialist} for t in db.scalars(stmt).all()]


@router.get("/treatments/{treatment_id}/prices")
def treatment_prices(treatment_id: int, db: Session = Depends(get_db)):
    t = db.get(Treatment, treatment_id)
    if not t:
        raise HTTPException(404, "Treatment not found")
    rows = db.execute(select(TreatmentPrice, Hospital).join(Hospital, Hospital.id == TreatmentPrice.hospital_id)
                      .where(TreatmentPrice.treatment_id == treatment_id)).all()
    items = [{"hospital_id": h.id, "hospital_name": h.name, "hospital_type": h.hospital_type, "city": h.city,
              "min": p.minimum_price, "max": p.maximum_price, "mid": (p.minimum_price + p.maximum_price) / 2,
              "verified": p.last_verified is not None, "verification_status": h.verification_status} for p, h in rows]
    items.sort(key=lambda x: x["mid"])
    return {"treatment": {"id": t.id, "name": t.treatment_name, "category": t.medical_category}, "prices": items,
            "disclaimer": "Prices marked unverified are demo estimates, not hospital-confirmed figures."}


@router.post("/saved-hospitals", status_code=201)
def save_hospital(body: SavedIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    if not db.get(Hospital, body.hospital_id):
        raise HTTPException(404, "Hospital not found")
    if not db.scalar(select(SavedHospital).where(SavedHospital.user_id == user.id, SavedHospital.hospital_id == body.hospital_id)):
        db.add(SavedHospital(user_id=user.id, hospital_id=body.hospital_id))
        db.commit()
    return {"hospital_id": body.hospital_id, "saved": True}


@router.get("/saved-hospitals")
def saved_hospitals(db: Session = Depends(get_db), user=Depends(get_current_user)):
    rows = db.scalars(select(Hospital).join(SavedHospital, SavedHospital.hospital_id == Hospital.id)
                      .where(SavedHospital.user_id == user.id).order_by(Hospital.name)).all()
    return [summary(h) for h in rows]


@router.delete("/saved-hospitals/{hospital_id}", status_code=204)
def unsave_hospital(hospital_id: int, db: Session = Depends(get_db), user=Depends(get_current_user)):
    row = db.scalar(select(SavedHospital).where(SavedHospital.user_id == user.id, SavedHospital.hospital_id == hospital_id))
    if not row:
        raise HTTPException(404, "Saved hospital not found")
    db.delete(row)
    db.commit()


@router.post("/corrections", status_code=201)
def submit_correction(body: CorrectionIn, db: Session = Depends(get_db), user=Depends(get_current_user)):
    if not db.get(Hospital, body.hospital_id):
        raise HTTPException(404, "Hospital not found")
    db.add(Correction(user_id=user.id, hospital_id=body.hospital_id, message=body.message.strip()))
    db.commit()
    return {"submitted": True}
