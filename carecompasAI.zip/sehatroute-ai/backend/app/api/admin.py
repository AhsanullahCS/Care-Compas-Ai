import json
from datetime import timedelta

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from app.core.deps import require_admin
from app.database.session import get_db
from app.models.models import (now, Correction, Doctor, HealthcareProgram, Hospital, HospitalProgram, HospitalTreatment,
                               SearchHistory, Treatment, TreatmentPrice, User)
from app.schemas.schemas import (DoctorIn, HospitalIn, HospitalProgramIn, HospitalTreatmentIn, HospitalUpdate, PriceIn,
                                 ProgramIn, TreatmentIn)

router = APIRouter(prefix="/api/admin", tags=["admin"], dependencies=[Depends(require_admin)])


def _get(db, model, id_, label):
    obj = db.get(model, id_)
    if not obj:
        raise HTTPException(404, f"{label} not found")
    return obj


@router.post("/hospitals", status_code=201)
def add_hospital(body: HospitalIn, db: Session = Depends(get_db)):
    h = Hospital(**body.model_dump(exclude={"facilities"}), facilities=json.dumps(body.facilities), verification_status="unverified", data_source="admin")
    db.add(h)
    db.commit()
    return {"id": h.id}


@router.put("/hospitals/{hospital_id}")
def update_hospital(hospital_id: int, body: HospitalUpdate, db: Session = Depends(get_db)):
    h = _get(db, Hospital, hospital_id, "Hospital")
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(h, k, json.dumps(v) if k == "facilities" else v)
    db.commit()
    return {"id": h.id}


@router.post("/hospitals/{hospital_id}/verify")
def verify_hospital(hospital_id: int, verified: bool = True, db: Session = Depends(get_db)):
    h = _get(db, Hospital, hospital_id, "Hospital")
    h.verification_status = "verified" if verified else "unverified"
    h.location_verified = verified
    db.commit()
    return {"id": h.id, "verification_status": h.verification_status}


@router.delete("/hospitals/{hospital_id}", status_code=204)
def delete_hospital(hospital_id: int, db: Session = Depends(get_db)):
    db.delete(_get(db, Hospital, hospital_id, "Hospital"))
    db.commit()


@router.post("/treatments", status_code=201)
def add_treatment(body: TreatmentIn, db: Session = Depends(get_db)):
    if db.scalar(select(Treatment).where(Treatment.treatment_name == body.treatment_name)):
        raise HTTPException(409, "Treatment already exists")
    t = Treatment(**body.model_dump())
    db.add(t)
    db.commit()
    return {"id": t.id}


@router.put("/hospital-treatments")
def set_hospital_treatment(body: HospitalTreatmentIn, db: Session = Depends(get_db)):
    _get(db, Hospital, body.hospital_id, "Hospital"), _get(db, Treatment, body.treatment_id, "Treatment")
    row = db.scalar(select(HospitalTreatment).where(HospitalTreatment.hospital_id == body.hospital_id, HospitalTreatment.treatment_id == body.treatment_id))
    if row:
        row.availability_status = body.availability_status
    else:
        db.add(HospitalTreatment(**body.model_dump()))
    db.commit()
    return {"ok": True}


@router.put("/prices")
def set_price(body: PriceIn, db: Session = Depends(get_db)):
    _get(db, Hospital, body.hospital_id, "Hospital"), _get(db, Treatment, body.treatment_id, "Treatment")
    row = db.scalar(select(TreatmentPrice).where(TreatmentPrice.hospital_id == body.hospital_id, TreatmentPrice.treatment_id == body.treatment_id))
    verified_at = now() if body.verified else None
    if row:
        row.minimum_price, row.maximum_price, row.last_verified = body.minimum_price, body.maximum_price, verified_at
    else:
        db.add(TreatmentPrice(hospital_id=body.hospital_id, treatment_id=body.treatment_id, minimum_price=body.minimum_price,
                              maximum_price=body.maximum_price, last_verified=verified_at))
    db.commit()
    return {"ok": True}


@router.get("/doctors/{hospital_id}")
def list_doctors(hospital_id: int, db: Session = Depends(get_db)):
    return [{"id": d.id, "name": d.name, "specialization": d.specialization, "availability_status": d.availability_status}
            for d in db.scalars(select(Doctor).where(Doctor.hospital_id == hospital_id)).all()]


@router.post("/doctors", status_code=201)
def add_doctor(body: DoctorIn, db: Session = Depends(get_db)):
    _get(db, Hospital, body.hospital_id, "Hospital")
    d = Doctor(**body.model_dump())
    db.add(d)
    db.commit()
    return {"id": d.id}


@router.delete("/doctors/{doctor_id}", status_code=204)
def delete_doctor(doctor_id: int, db: Session = Depends(get_db)):
    db.delete(_get(db, Doctor, doctor_id, "Doctor"))
    db.commit()


@router.post("/programs", status_code=201)
def add_program(body: ProgramIn, db: Session = Depends(get_db)):
    if db.scalar(select(HealthcareProgram).where(HealthcareProgram.program_name == body.program_name)):
        raise HTTPException(409, "Program already exists")
    p = HealthcareProgram(**body.model_dump())
    db.add(p)
    db.commit()
    return {"id": p.id}


@router.put("/hospital-programs")
def set_hospital_program(body: HospitalProgramIn, db: Session = Depends(get_db)):
    _get(db, Hospital, body.hospital_id, "Hospital"), _get(db, HealthcareProgram, body.program_id, "Program")
    row = db.scalar(select(HospitalProgram).where(HospitalProgram.hospital_id == body.hospital_id, HospitalProgram.program_id == body.program_id))
    when = now() if body.verified else None
    if row:
        row.acceptance_status, row.verification_date = body.acceptance_status, when
    else:
        db.add(HospitalProgram(hospital_id=body.hospital_id, program_id=body.program_id, acceptance_status=body.acceptance_status, verification_date=when))
    db.commit()
    return {"ok": True}


@router.get("/corrections")
def list_corrections(db: Session = Depends(get_db)):
    rows = db.execute(select(Correction, Hospital.name, User.email).join(Hospital, Hospital.id == Correction.hospital_id)
                      .outerjoin(User, User.id == Correction.user_id).order_by(Correction.created_at.desc()).limit(100)).all()
    return [{"id": c.id, "hospital_id": c.hospital_id, "hospital_name": n, "user_email": e, "message": c.message, "status": c.status,
             "created_at": c.created_at.isoformat()} for c, n, e in rows]


@router.post("/corrections/{correction_id}/resolve")
def resolve_correction(correction_id: int, db: Session = Depends(get_db)):
    c = _get(db, Correction, correction_id, "Correction")
    c.status = "resolved"
    db.commit()
    return {"id": c.id, "status": c.status}


@router.get("/analytics")
def analytics(db: Session = Depends(get_db)):
    count = lambda stmt: db.scalar(stmt) or 0  # noqa: E731
    since = now() - timedelta(days=14)
    by_day = db.execute(select(func.date(SearchHistory.created_at), func.count()).where(SearchHistory.created_at >= since)
                        .group_by(func.date(SearchHistory.created_at)).order_by(func.date(SearchHistory.created_at))).all()
    return {"users": count(select(func.count(User.id))), "hospitals": count(select(func.count(Hospital.id))),
            "searches": count(select(func.count(SearchHistory.id))),
            "open_corrections": count(select(func.count(Correction.id)).where(Correction.status == "open")),
            "by_type": [{"name": t, "value": n} for t, n in db.execute(select(Hospital.hospital_type, func.count()).group_by(Hospital.hospital_type)).all()],
            "by_verification": [{"name": t, "value": n} for t, n in db.execute(select(Hospital.verification_status, func.count()).group_by(Hospital.verification_status)).all()],
            "top_searches": [{"name": q, "value": n} for q, n in db.execute(select(SearchHistory.search_query, func.count().label("n")).group_by(SearchHistory.search_query).order_by(func.count().desc()).limit(8)).all()],
            "searches_per_day": [{"day": str(d), "searches": n} for d, n in by_day]}
