import re

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select
from sqlalchemy.orm import Session

from app.ai import nlp
from app.core.deps import get_optional_user
from app.database.session import get_db
from app.models.models import HealthcareProgram, Treatment
from app.schemas.schemas import AssistantIn, ExplainIn, ReferralIn, SearchRequest
from app.services.search import run_search

router = APIRouter(prefix="/api", tags=["ai"])

EMERGENCY = re.compile(r"chest pain|heart attack|can'?t breathe|cannot breathe|difficulty breathing|unconscious|severe bleeding|bleeding heavily|"
                       r"overdose|poison|suicid|stroke (now|right now)|emergency|accident|not breathing|seizure (now|right now)", re.I)
MEDICAL_ADVICE = re.compile(r"diagnos|what (disease|illness) do i have|which (medicine|medication|drug)|prescribe|dosage|what should i take|"
                            r"do i have (cancer|a heart)", re.I)
AFFORD = re.compile(r"afford|cheap|low cost|low-cost|budget|poor|free|expensive|money|financial", re.I)
EMERGENCY_TEXT = ("This may be an emergency. Please call your local emergency service now (in Pakistan, Rescue 1122 or Edhi 115 - "
                  "check what works in your area) or go to the nearest emergency department immediately. Do not delay care to search for a hospital here.")
DISCLAIMER = "Sehat Assistant does not diagnose conditions, prescribe medicine or replace a doctor. Hospital details shown are demo/unverified unless marked verified."


@router.post("/ai/recommend")
def recommend(body: SearchRequest, db: Session = Depends(get_db), user=Depends(get_optional_user)):
    return run_search(db, body, user)


@router.post("/ai/explain")
def explain(body: ExplainIn, db: Session = Depends(get_db)):
    data = body.model_dump(exclude={"hospital_id"})
    data.update(page=1, page_size=200)
    res = run_search(db, SearchRequest(**data))
    hit = next((r for r in res["results"] if r["id"] == body.hospital_id), None)
    if not hit:
        raise HTTPException(404, "Hospital is not eligible for this search (it may not offer the treatment or is outside the radius)")
    return {"hospital_id": hit["id"], "score": hit["score"], "breakdown": hit["breakdown"], "explanation": hit["explanation"],
            "flags": hit["flags"], "weights_note": "Weights are renormalised across factors that could be computed for this search."}


@router.post("/ai/referral")
def referral(body: ReferralIn, db: Session = Depends(get_db), user=Depends(get_optional_user)):
    """Healthcare Referral Assistant: extract specialist/treatment/department from referral text, then match hospitals."""
    ex = nlp.extract_requirements(body.text, db.scalars(select(Treatment)).all())
    out = {"extraction": ex, "disclaimer": "Extraction maps wording in the text to our catalogue. It is not a diagnosis."}
    if body.lat is not None and body.lng is not None and ex["department"]:
        out["search"] = run_search(db, SearchRequest(lat=body.lat, lng=body.lng, radius_km=body.radius_km, query=body.text, page_size=10), user)
    return out


@router.post("/assistant/chat")
def chat(body: AssistantIn, db: Session = Depends(get_db), user=Depends(get_optional_user)):
    msg = body.message
    if EMERGENCY.search(msg):
        return {"reply": EMERGENCY_TEXT, "emergency": True, "hospitals": [], "disclaimer": DISCLAIMER}
    if MEDICAL_ADVICE.search(msg):
        return {"reply": "I can't diagnose conditions or recommend medicines - please speak to a doctor. If you already know the treatment or "
                         "specialist you need (for example from a referral), tell me and I'll find hospitals that offer it.",
                "emergency": False, "hospitals": [], "disclaimer": DISCLAIMER}
    low = msg.lower()
    if re.search(r"sehat card|insurance|zakat|welfare|bait|scheme|program", low):
        progs = db.scalars(select(HealthcareProgram)).all()
        names = "; ".join(f"{p.program_name} ({p.program_type.replace('_', ' ')})" for p in progs)
        return {"reply": f"The platform tracks these financial-assistance options: {names}. Pick yours in Financial Assistance or the search filters and I'll prioritise "
                         "hospitals that list it. Acceptance shown here is demo data unless marked verified - always confirm with the hospital.",
                "emergency": False, "hospitals": [], "disclaimer": DISCLAIMER}
    ex = nlp.extract_requirements(msg, db.scalars(select(Treatment)).all())
    if ex["department"]:
        lat, lng = (body.lat, body.lng) if body.lat is not None and body.lng is not None else (33.6844, 73.0479)
        weights = {"affordability": 0.30, "government": 0.25} if AFFORD.search(msg) else None
        res = run_search(db, SearchRequest(lat=lat, lng=lng, radius_km=body.radius_km, query=msg, weights=weights, page_size=3), user)
        top = res["results"]
        what = ex["treatment_names"][0] if ex["treatment_names"] else f"{ex['department'].lower()} care"
        loc = "your location" if body.lat is not None else "central Islamabad (no location shared)"
        if not top:
            return {"reply": f"I found no hospitals offering {what} within {body.radius_km} km of {loc}. Try a larger radius.", "emergency": False,
                    "hospitals": [], "disclaimer": DISCLAIMER}
        lines = [f"{i + 1}. {r['name']} - {r['distance_km']} km, score {r['score']}/100" + (f", est. PKR {r['price']['min']:,.0f}-{r['price']['max']:,.0f} (demo estimate)" if r["price"] else "")
                 for i, r in enumerate(top)]
        pri = " I weighted affordability and government support higher because you mentioned cost." if weights else ""
        return {"reply": f"Here are hospitals near {loc} that offer {what}:\n" + "\n".join(lines) + pri +
                         "\nOpen the Dashboard or Map for full details and a cost comparison.",
                "emergency": False, "hospitals": [{"id": r["id"], "name": r["name"], "score": r["score"]} for r in top], "disclaimer": DISCLAIMER}
    if "compare" in low or "cost" in low or "price" in low:
        reply = "Choose a specific treatment in the Dashboard search; the comparison panel then shows the lowest estimated cost, nearest eligible hospital, hospitals with financial support and the best overall match."
    else:
        reply = ("Tell me the treatment or specialist you need (for example 'angioplasty', 'dialysis' or 'cardiologist') and, if you can, share your location. "
                 "I'll find eligible hospitals and rank them by treatment match, specialist availability, distance, estimated cost and financial support.")
    return {"reply": reply, "emergency": False, "hospitals": [], "disclaimer": DISCLAIMER}
