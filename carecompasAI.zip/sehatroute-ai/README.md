# SehatRoute AI — Smart Healthcare Access & Hospital Recommendation Platform

Hackathon MVP (AI for Civic Solutions 2026). Patients search a treatment, specialist or referral text; the platform returns only hospitals that **offer the treatment**, ranks them with a transparent weighted AI score (treatment match, specialist, distance, affordability, government support, card/insurance), compares estimated costs, and shows everything on an interactive Google-Maps-style map.

> **Data honesty:** the bundled dataset is **synthetic demo data** (fictional hospital names ending "(Demo)", fixed approximate area coordinates, invented prices/doctors/scheme acceptance). The UI labels it "Demo data" everywhere. Admins can verify hospitals; only then do labels change to "Verified". The platform does not diagnose, prescribe, or replace a doctor.

## Quick start (about 5 minutes)

Requirements: Python 3.10+, Node 18+. No external API keys needed.

```bash
# 1) Backend  (terminal 1)
cd backend
python -m venv .venv && source .venv/bin/activate      # Windows: .venv\Scripts\activate
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000              # creates the SQLite DB and seeds demo data on first start

# 2) Frontend (terminal 2)
cd frontend
npm install
npm run dev                                            # http://localhost:5173  (proxies /api -> :8000)
```
API docs: http://localhost:8000/docs

Seeded demo logins: patient `patient@sehatroute.demo / Patient@12345` · admin `admin@sehatroute.demo / Admin@12345` (change via `.env`; copy `.env.example`).
Reset data: `cd backend && python -m app.database.seed --reset`. Regenerate the dataset: `python dataset/build_demo_dataset.py`.
PostgreSQL: set `DATABASE_URL=postgresql+psycopg2://...`, `pip install psycopg2-binary` (schema also in `backend/migrations/001_init.sql`).
Map tiles come from OpenStreetMap, so the browser needs internet access.

## Interactive nearby-hospital map (`/map`)
- Asks for browser geolocation, centres on you (blue pulsing marker + radius circle). If denied, falls back to the selected area with a message.
- Every hospital in the radius is a **red marker at its stored database coordinates** (no random coordinates). A badge on each pin shows **D = demo (approximate) location** or **✓ = verified location**; popups say the same.
- Popup: name, type, distance, treatment, estimated cost, accepted cards (marked unverified), AI score, **View Details**.
- Zoom controls, "return to my location" button, radius/treatment/type/program/budget/financial-aid/sort filters that re-query the backend automatically.
- Synced sidebar: click a card → marker highlights and popup opens (zooms/spiderfies out of clusters); click a marker → card highlights and scrolls into view.
- Marker clustering (leaflet.markercluster); responsive: side-by-side on desktop, Map/List tabs on mobile.

## AI recommendation engine (`backend/app/ai/recommender.py`)
Default weights: treatment 30 · specialist 20 · distance 15 · affordability 15 · government support 15 · insurance 5 (adjustable per request via `weights`, renormalised).
- **Eligibility first:** hospitals without the requested treatment are never returned, however cheap or close.
- All factors normalised 0–100; factors that can't be computed (e.g. no treatment chosen → no price) are dropped and weights renormalised.
- Missing/unverified info is never a confirmed positive: scheme acceptance is 100 only if verified, 70 if listed but unverified (demo), 0 otherwise; missing price scores 0.
- Each result has a score, factor breakdown, plain-language explanation and data flags. Cost comparison + savings (lowest cost, nearest, with financial support, best overall) appear when one specific treatment is selected.
- Referral assistant (`/api/ai/referral`, and free-text search): rule-based extraction of department/specialist/treatment (optional Gemini, validated against the catalogue). No diagnosis.
- Sehat Assistant (`/assistant`): emergency wording → emergency advice only; diagnosis/medicine requests are declined; hospital answers come from real database queries.

## Tests
```bash
cd backend && pytest -q          # 16 API tests: auth, radius, eligibility, ranking, cost comparison, filters, assistant safety, admin
cd frontend && npm run build     # production build check
```
## Hackathon demo script (5 min)
1. Landing page → **Find Healthcare**. 2. Dashboard: type *"referred for angioplasty, cannot afford private hospital"*, radius 50 km → note the extracted specialist/treatment, ranked results, **"Why this score?"**, cost comparison and savings calculator. 3. Pick *Sehat Card Plus* under "My healthcare card" and re-search → programs prioritised, still labelled unverified. 4. **Hospital Map** → allow location, choose *Angioplasty*, change radius 10 → 200 km, toggle Government, click cards/markers/clusters, **View Details** → price comparison chart. 5. **Sehat Assistant**: ask about heart treatment affordably, then type "chest pain right now" to show the emergency guard. 6. Log in as admin → verify a hospital, update a price, resolve a correction; show the analytics.

## Layout
`frontend/` React + Vite + Tailwind + Leaflet · `backend/app/{api,models,schemas,services,ai,database,core}` FastAPI · `dataset/` generator + `demo_hospitals.json` · `docs/API.md`.

## Known limitations
In-memory rate limiter (use a gateway/Redis in production); JWT stored in localStorage; SQL schema managed by `create_all` plus the SQL file (no Alembic); Gemini path is untested without a key; nothing here is real clinical or pricing data.
